<?php

namespace SSEOAISaaS;

/**
 * Payment Processor
 * 
 * Handles payment processing via Stripe and Mollie
 * - Stripe: Credit cards, subscriptions (global)
 * - Mollie: iDEAL, Bancontact, SEPA (Europe)
 */
class PaymentProcessor
{
    private string $provider;
    private string $stripeSecretKey;
    private string $mollieApiKey;
    private string $currency;
    private TenantRepository $tenants;

    private const STRIPE_API = 'https://api.stripe.com/v1';
    private const MOLLIE_API = 'https://api.mollie.com/v2';

    public function __construct(TenantRepository $tenants)
    {
        $this->tenants = $tenants;
        $this->provider = get_option('sseo_ai_saas_payment_provider', 'stripe');
        $this->stripeSecretKey = get_option('sseo_ai_saas_stripe_secret', '');
        $this->mollieApiKey = get_option('sseo_ai_saas_mollie_api_key', '');
        $this->currency = get_option('sseo_ai_saas_currency', 'EUR');
    }

    /**
     * Get available payment providers
     */
    public static function getProviders(): array
    {
        return [
            'stripe' => [
                'name' => 'Stripe',
                'description' => 'Credit cards, subscriptions (Global)',
                'methods' => ['card', 'sepa_debit'],
                'supports_subscriptions' => true,
            ],
            'mollie' => [
                'name' => 'Mollie',
                'description' => 'iDEAL, Bancontact, SEPA (Europe)',
                'methods' => ['ideal', 'bancontact', 'sofort', 'sepa_direct_debit'],
                'supports_subscriptions' => true,
            ],
        ];
    }

    /**
     * Create a subscription checkout for a tenant
     */
    public function createSubscription(string $tenantKey, string $tier): array|\WP_Error
    {
        $tenant = $this->tenants->getTenant($tenantKey);
        if (!$tenant) {
            return new \WP_Error('tenant_not_found', __('Tenant not found', 'sseo-ai-saas'));
        }

        $pricing = $this->getTierPricing($tier);
        if (is_wp_error($pricing)) {
            return $pricing;
        }

        switch ($this->provider) {
            case 'stripe':
                return $this->createStripeSubscription($tenant, $tier, $pricing);
            case 'mollie':
                return $this->createMollieCheckout($tenant, $tier, $pricing);
            default:
                return new \WP_Error('invalid_provider', __('Invalid payment provider', 'sseo-ai-saas'));
        }
    }

    /**
     * Get pricing for a tier
     */
    private function getTierPricing(string $tier): array|\WP_Error
    {
        $defaultPricing = [
            'free' => ['amount' => 0.00, 'interval' => 'month'],
            'trial' => ['amount' => 0.00, 'interval' => 'month'],
            'starter' => ['amount' => 19.00, 'interval' => 'month'],
            'professional' => ['amount' => 49.00, 'interval' => 'month'],
            'business' => ['amount' => 99.00, 'interval' => 'month'],
            'agency' => ['amount' => 199.00, 'interval' => 'month'],
        ];

        // Allow custom pricing via option
        $customPricing = get_option('sseo_ai_saas_pricing', []);
        if (is_array($customPricing) && !empty($customPricing)) {
            $defaultPricing = array_merge($defaultPricing, $customPricing);
        }

        if (!isset($defaultPricing[$tier])) {
            return new \WP_Error('invalid_tier', __('Invalid subscription tier', 'sseo-ai-saas'));
        }

        return $defaultPricing[$tier];
    }

    /**
     * Create Stripe subscription checkout session
     */
    private function createStripeSubscription(array $tenant, string $tier, array $pricing): array|\WP_Error
    {
        if (empty($this->stripeSecretKey)) {
            return new \WP_Error('stripe_not_configured', __('Stripe secret key is not configured', 'sseo-ai-saas'));
        }

        $priceResult = $this->createStripePrice($tier, $pricing);
        if (is_wp_error($priceResult)) {
            return $priceResult;
        }

        $successUrl = $this->getReturnUrl($tenant['tenant_key'], 'stripe');
        $cancelUrl = $this->getCancelUrl($tenant['tenant_key']);

        $session = $this->stripeRequest('checkout/sessions', [
            'mode' => 'subscription',
            'client_reference_id' => $tenant['tenant_key'],
            'customer_email' => $tenant['email'],
            'line_items' => [
                [
                    'price' => $priceResult['id'],
                    'quantity' => 1,
                ],
            ],
            'success_url' => $successUrl,
            'cancel_url' => $cancelUrl,
            'metadata' => [
                'tenant_key' => $tenant['tenant_key'],
                'tier' => $tier,
            ],
        ]);

        if (is_wp_error($session)) {
            return $session;
        }

        $this->tenants->setTenantSetting($tenant['tenant_key'], 'stripe_session_id', $session['id']);

        return [
            'provider' => 'stripe',
            'tenant_key' => $tenant['tenant_key'],
            'tier' => $tier,
            'amount' => $pricing['amount'],
            'currency' => $this->currency,
            'status' => 'pending_setup',
            'message' => __('Redirect to Stripe to complete payment setup.', 'sseo-ai-saas'),
            'checkout_url' => $session['url'] ?? '',
        ];
    }

    /**
     * Create a Stripe price for a tier
     */
    private function createStripePrice(string $tier, array $pricing): array|\WP_Error
    {
        $product = $this->stripeRequest('products', [
            'name' => 'Fyndable SmartSEO - ' . ucfirst($tier),
            'metadata' => ['tier' => $tier],
        ]);

        if (is_wp_error($product)) {
            return $product;
        }

        $currency = strtolower($this->currency);
        $amountCents = (int) round($pricing['amount'] * 100);

        $price = $this->stripeRequest('prices', [
            'unit_amount' => $amountCents,
            'currency' => $currency,
            'recurring' => ['interval' => $pricing['interval']],
            'product' => $product['id'],
            'metadata' => ['tier' => $tier],
        ]);

        if (is_wp_error($price)) {
            return $price;
        }

        return $price;
    }

    /**
     * Create Mollie checkout for the first recurring payment
     */
    private function createMollieCheckout(array $tenant, string $tier, array $pricing): array|\WP_Error
    {
        if (empty($this->mollieApiKey)) {
            return new \WP_Error('mollie_not_configured', __('Mollie API key is not configured', 'sseo-ai-saas'));
        }

        $customer = $this->createMollieCustomer($tenant);
        if (is_wp_error($customer)) {
            return $customer;
        }

        $customerId = $customer['id'];
        $this->tenants->setTenantSetting($tenant['tenant_key'], 'mollie_customer_id', $customerId);

        $payment = $this->mollieRequest('payments', [
            'amount' => $this->mollieAmount($pricing['amount']),
            'customerId' => $customerId,
            'sequenceType' => 'first',
            'description' => sprintf(__('Fyndable SmartSEO %s subscription', 'sseo-ai-saas'), ucfirst($tier)),
            'redirectUrl' => $this->getReturnUrl($tenant['tenant_key'], 'mollie'),
            'webhookUrl' => $this->getWebhookUrl('mollie'),
            'metadata' => [
                'tenant_key' => $tenant['tenant_key'],
                'tier' => $tier,
            ],
        ]);

        if (is_wp_error($payment)) {
            return $payment;
        }

        $this->tenants->setTenantSetting($tenant['tenant_key'], 'mollie_payment_id', $payment['id']);

        return [
            'provider' => 'mollie',
            'tenant_key' => $tenant['tenant_key'],
            'tier' => $tier,
            'amount' => $pricing['amount'],
            'currency' => $this->currency,
            'status' => 'pending_payment',
            'message' => __('Redirect to Mollie to complete the first payment.', 'sseo-ai-saas'),
            'checkout_url' => $payment['_links']['checkout']['href'] ?? '',
        ];
    }

    /**
     * Create a Mollie customer
     */
    private function createMollieCustomer(array $tenant): array|\WP_Error
    {
        $existing = $this->tenants->getTenantSetting($tenant['tenant_key'], 'mollie_customer_id', '');
        if (!empty($existing)) {
            $customer = $this->mollieRequest('customers/' . $existing, [], 'GET');
            if (!is_wp_error($customer)) {
                return $customer;
            }
        }

        return $this->mollieRequest('customers', [
            'email' => $tenant['email'],
            'name' => $tenant['name'],
            'metadata' => [
                'tenant_key' => $tenant['tenant_key'],
            ],
        ]);
    }

    /**
     * Fetch a Mollie payment by ID
     */
    public function fetchMolliePayment(string $paymentId): array|\WP_Error
    {
        if (empty($this->mollieApiKey)) {
            return new \WP_Error('mollie_not_configured', __('Mollie API key is not configured', 'sseo-ai-saas'));
        }

        return $this->mollieRequest('payments/' . $paymentId, [], 'GET');
    }

    /**
     * Create a Mollie subscription after a successful first payment
     */
    public function createMollieSubscription(string $tenantKey, array $payment): array|\WP_Error
    {
        $tenant = $this->tenants->getTenant($tenantKey);
        if (!$tenant) {
            return new \WP_Error('tenant_not_found', __('Tenant not found', 'sseo-ai-saas'));
        }

        $customerId = $payment['customerId'] ?? '';
        $mandateId = $payment['mandateId'] ?? '';
        $tier = $payment['metadata']['tier'] ?? $tenant['tier'];

        if (empty($customerId) || empty($mandateId)) {
            return new \WP_Error('mollie_no_mandate', __('Mollie payment does not have a mandate yet', 'sseo-ai-saas'));
        }

        $pricing = $this->getTierPricing($tier);
        if (is_wp_error($pricing)) {
            return $pricing;
        }

        $startDate = (new \DateTime('now', new \DateTimeZone('UTC')))
            ->add(new \DateInterval('P1M'))
            ->format('Y-m-d');

        $subscription = $this->mollieRequest('customers/' . $customerId . '/subscriptions', [
            'amount' => $this->mollieAmount($pricing['amount']),
            'interval' => '1 month',
            'startDate' => $startDate,
            'description' => sprintf(__('Fyndable SmartSEO %s subscription', 'sseo-ai-saas'), ucfirst($tier)),
            'mandateId' => $mandateId,
            'webhookUrl' => $this->getWebhookUrl('mollie'),
            'metadata' => [
                'tenant_key' => $tenantKey,
                'tier' => $tier,
            ],
        ]);

        if (is_wp_error($subscription)) {
            return $subscription;
        }

        $this->tenants->setTenantSetting($tenantKey, 'mollie_subscription_id', $subscription['id']);
        $this->tenants->setTenantSetting($tenantKey, 'mollie_mandate_id', $mandateId);

        $this->tenants->updateTenant($tenantKey, [
            'status' => 'active',
            'payment_status' => 'active',
            'last_payment_at' => current_time('mysql'),
            'expires_at' => gmdate('Y-m-d H:i:s', strtotime('+1 month')),
        ]);

        return $subscription;
    }

    /**
     * Cancel a subscription
     */
    public function cancelSubscription(string $tenantKey): array|\WP_Error
    {
        $tenant = $this->tenants->getTenant($tenantKey);
        if (!$tenant) {
            return new \WP_Error('tenant_not_found', __('Tenant not found', 'sseo-ai-saas'));
        }

        $stripeSubId = $this->tenants->getTenantSetting($tenantKey, 'stripe_subscription_id', '');
        $mollieSubId = $this->tenants->getTenantSetting($tenantKey, 'mollie_subscription_id', '');

        if (!empty($stripeSubId)) {
            $this->stripeRequest('subscriptions/' . $stripeSubId, ['cancel_at_period_end' => true], 'POST');
        } elseif (!empty($mollieSubId)) {
            $mollieCustomerId = $this->tenants->getTenantSetting($tenantKey, 'mollie_customer_id', '');
            if (!empty($mollieCustomerId)) {
                $this->mollieRequest('customers/' . $mollieCustomerId . '/subscriptions/' . $mollieSubId, [], 'DELETE');
            }
        }

        $this->tenants->updateTenant($tenantKey, [
            'status' => 'cancelled',
            'payment_status' => 'cancelled',
        ]);

        return [
            'success' => true,
            'message' => __('Subscription cancelled successfully', 'sseo-ai-saas'),
        ];
    }

    /**
     * Upgrade/downgrade subscription tier
     */
    public function changeTier(string $tenantKey, string $newTier): array|\WP_Error
    {
        $tenant = $this->tenants->getTenant($tenantKey);
        if (!$tenant) {
            return new \WP_Error('tenant_not_found', __('Tenant not found', 'sseo-ai-saas'));
        }

        $pricing = $this->getTierPricing($newTier);
        if (is_wp_error($pricing)) {
            return $pricing;
        }

        $stripeSubId = $this->tenants->getTenantSetting($tenantKey, 'stripe_subscription_id', '');
        if (!empty($stripeSubId)) {
            $items = $this->stripeRequest('subscriptions/' . $stripeSubId, [], 'GET');
            if (!is_wp_error($items) && !empty($items['items']['data'][0]['id'])) {
                $priceResult = $this->createStripePrice($newTier, $pricing);
                if (!is_wp_error($priceResult)) {
                    $this->stripeRequest('subscriptions/' . $stripeSubId, [
                        'items' => [
                            [
                                'id' => $items['items']['data'][0]['id'],
                                'price' => $priceResult['id'],
                            ],
                        ],
                        'proration_behavior' => 'create_prorations',
                    ], 'POST');
                }
            }
        }

        $mollieSubId = $this->tenants->getTenantSetting($tenantKey, 'mollie_subscription_id', '');
        if (!empty($mollieSubId)) {
            $mollieCustomerId = $this->tenants->getTenantSetting($tenantKey, 'mollie_customer_id', '');
            if (!empty($mollieCustomerId)) {
                $this->mollieRequest('customers/' . $mollieCustomerId . '/subscriptions/' . $mollieSubId, [
                    'amount' => $this->mollieAmount($pricing['amount']),
                ], 'PATCH');
            }
        }

        $this->tenants->updateTenant($tenantKey, ['tier' => $newTier]);

        return [
            'success' => true,
            'message' => sprintf(__('Subscription upgraded to %s', 'sseo-ai-saas'), ucfirst($newTier)),
            'old_tier' => $tenant['tier'],
            'new_tier' => $newTier,
        ];
    }

    /**
     * Generic Stripe API request
     */
    private function stripeRequest(string $endpoint, array $params, string $method = 'POST'): array|\WP_Error
    {
        $url = self::STRIPE_API . '/' . $endpoint;
        $args = [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->stripeSecretKey,
                'Content-Type' => 'application/x-www-form-urlencoded',
            ],
            'timeout' => 60,
        ];

        if ($method === 'GET') {
            if (!empty($params)) {
                $url = add_query_arg($params, $url);
            }
            $response = wp_remote_get($url, $args);
        } else {
            $args['body'] = http_build_query($params);
            $args['method'] = $method;
            $response = wp_remote_request($url, $args);
        }

        if (is_wp_error($response)) {
            return $response;
        }

        $statusCode = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($body)) {
            $body = [];
        }

        if ($statusCode >= 400 || !empty($body['error'])) {
            $message = $body['error']['message'] ?? __('Stripe API request failed', 'sseo-ai-saas');
            return new \WP_Error('stripe_request_failed', $message, ['status' => $statusCode]);
        }

        return $body;
    }

    /**
     * Generic Mollie API request
     */
    private function mollieRequest(string $endpoint, array $params, string $method = 'POST'): array|\WP_Error
    {
        $url = self::MOLLIE_API . '/' . ltrim($endpoint, '/');
        $args = [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->mollieApiKey,
                'Content-Type' => 'application/json',
            ],
            'timeout' => 60,
        ];

        if ($method === 'GET') {
            if (!empty($params)) {
                $url = add_query_arg($params, $url);
            }
            $response = wp_remote_get($url, $args);
        } else {
            $args['body'] = json_encode($params);
            $args['method'] = $method;
            $response = wp_remote_request($url, $args);
        }

        if (is_wp_error($response)) {
            return $response;
        }

        $statusCode = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($body)) {
            $body = [];
        }

        if ($statusCode >= 400 || (!empty($body['status']) && $body['status'] >= 400) || !empty($body['detail'])) {
            $message = $body['detail'] ?? ($body['title'] ?? __('Mollie API request failed', 'sseo-ai-saas'));
            return new \WP_Error('mollie_request_failed', $message, ['status' => $statusCode]);
        }

        return $body;
    }

    /**
     * Format amount for Mollie (currency + value)
     */
    private function mollieAmount(float $amount): array
    {
        $decimals = in_array(strtoupper($this->currency), ['JPY', 'KRW', 'CLP', 'ISK'], true) ? 0 : 2;
        $value = number_format($amount, $decimals, '.', '');

        return [
            'currency' => strtoupper($this->currency),
            'value' => $value,
        ];
    }

    /**
     * Return URL after payment
     */
    private function getReturnUrl(string $tenantKey, string $provider): string
    {
        return add_query_arg([
            'fyndable_payment' => 'success',
            'provider' => $provider,
            'tenant_key' => $tenantKey,
        ], home_url('/thank-you/'));
    }

    /**
     * Cancel URL
     */
    private function getCancelUrl(string $tenantKey): string
    {
        return add_query_arg([
            'fyndable_payment' => 'cancel',
            'tenant_key' => $tenantKey,
        ], home_url('/pricing/'));
    }

    /**
     * Webhook URL for a provider
     */
    public function getWebhookUrl(string $provider): string
    {
        return rest_url('ai-seo-saas/v1/webhooks/' . $provider);
    }

    /**
     * Find tenant by customer ID
     */
    private function findTenantByCustomerId(string $customerId, string $provider): ?string
    {
        return $this->findTenantByProviderId("{$provider}_customer_id", $customerId);
    }

    /**
     * Find tenant by subscription ID
     */
    private function findTenantBySubscriptionId(string $subscriptionId, string $provider): ?string
    {
        return $this->findTenantByProviderId("{$provider}_subscription_id", $subscriptionId);
    }

    /**
     * Find tenant by payment/session ID
     */
    public function findTenantByPaymentId(string $paymentId, string $key): ?string
    {
        return $this->findTenantByProviderId($key, $paymentId);
    }

    /**
     * Find tenant by provider setting
     */
    private function findTenantByProviderId(string $key, string $value): ?string
    {
        global $wpdb;
        $settingsTable = $wpdb->prefix . 'sseo_ai_tenant_settings';
        $tenantsTable = $wpdb->prefix . 'sseo_ai_tenants';

        $tenantId = $wpdb->get_var($wpdb->prepare(
            "SELECT tenant_id FROM $settingsTable 
             WHERE setting_key = %s AND setting_value = %s",
            $key,
            $value
        ));

        if ($tenantId) {
            $tenantKey = $wpdb->get_var($wpdb->prepare(
                "SELECT tenant_key FROM $tenantsTable WHERE id = %d",
                $tenantId
            ));
            return $tenantKey ?: null;
        }

        return null;
    }

    /**
     * Send payment failure notification
     */
    private function notifyPaymentFailure(string $tenantKey, array $event, string $provider): void
    {
        $adminEmail = get_option('admin_email');
        $tenant = $this->tenants->getTenant($tenantKey);

        if ($tenant) {
            $subject = sprintf(__('Payment Failed: %s', 'sseo-ai-saas'), $tenant['name']);
            $message = sprintf(
                __("Payment failed for tenant: %s\nProvider: %s\nTenant Email: %s\n\nPlease check the payment dashboard.", 'sseo-ai-saas'),
                $tenant['name'],
                ucfirst($provider),
                $tenant['email']
            );

            wp_mail($adminEmail, $subject, $message);
        }
    }
}
