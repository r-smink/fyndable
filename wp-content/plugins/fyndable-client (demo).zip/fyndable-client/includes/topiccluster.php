<?php

namespace SSEOAIClient;

/**
 * Topic Cluster / Topical Authority Map
 * 
 * Generates pillar-cluster content maps for building topical authority.
 * Identifies hub pages, supporting content, and internal linking strategy.
 * Comparable to MarketMuse Cluster Analysis, NeuronWriter topical maps.
 * 
 * Also audits existing site content to map current topical coverage
 * and identify content gaps in your cluster strategy.
 */
class TopicCluster
{
    private Settings $settings;
    private LlmClient $llm;
    private ?ContentBrief $contentBrief = null;
    private ?ContentOptimizer $contentOptimizer = null;
    private ?SmartTags $smartTags = null;
    private ?FAQSchema $faqSchema = null;
    private ?OpenGraph $openGraph = null;
    private ?TruSEOScore $truSEO = null;
    private ?GeoContentScore $geoScore = null;

    public function __construct(
        Settings $settings,
        LlmClient $llm,
        ?ContentBrief $contentBrief = null,
        ?ContentOptimizer $contentOptimizer = null,
        ?SmartTags $smartTags = null,
        ?FAQSchema $faqSchema = null,
        ?OpenGraph $openGraph = null,
        ?TruSEOScore $truSEO = null,
        ?GeoContentScore $geoScore = null
    ) {
        $this->settings = $settings;
        $this->llm = $llm;
        $this->contentBrief = $contentBrief;
        $this->contentOptimizer = $contentOptimizer;
        $this->smartTags = $smartTags;
        $this->faqSchema = $faqSchema;
        $this->openGraph = $openGraph;
        $this->truSEO = $truSEO;
        $this->geoScore = $geoScore;
    }

    public function register(): void
    {
        add_action('rest_api_init', [$this, 'registerRestRoutes']);
        // Menu registration moved to Client class
    }

    public function addMenu(): void
    {
        add_submenu_page(
            'ai-seo-client',
            __('Topic Clusters', 'ai-seo-client'),
            __('Topic Clusters', 'ai-seo-client'),
            'edit_posts',
            'ai-seo-topic-clusters',
            [$this, 'renderPage']
        );
    }

    public function registerRestRoutes(): void
    {
        register_rest_route('sseo-ai/v1', '/clusters/generate', [
            'methods' => 'POST',
            'callback' => [$this, 'restGenerateCluster'],
            'permission_callback' => fn() => current_user_can('edit_posts'),
        ]);

        register_rest_route('sseo-ai/v1', '/clusters/audit', [
            'methods' => 'POST',
            'callback' => [$this, 'restAuditExistingContent'],
            'permission_callback' => fn() => current_user_can('edit_posts'),
        ]);

        register_rest_route('sseo-ai/v1', '/clusters/save', [
            'methods' => 'POST',
            'callback' => [$this, 'restSaveCluster'],
            'permission_callback' => fn() => current_user_can('edit_posts'),
        ]);

        register_rest_route('sseo-ai/v1', '/clusters/list', [
            'methods' => 'GET',
            'callback' => [$this, 'restListClusters'],
            'permission_callback' => fn() => current_user_can('edit_posts'),
        ]);

        register_rest_route('sseo-ai/v1', '/clusters/(?P<id>\d+)', [
            'methods' => 'DELETE',
            'callback' => [$this, 'restDeleteCluster'],
            'permission_callback' => fn() => current_user_can('edit_posts'),
        ]);

        register_rest_route('sseo-ai/v1', '/clusters/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'restGetCluster'],
            'permission_callback' => fn() => current_user_can('edit_posts'),
        ]);

        // Content generation endpoint for cluster items
        register_rest_route('sseo-ai/v1', '/clusters/generate-content', [
            'methods' => 'POST',
            'callback' => [$this, 'restGenerateClusterContent'],
            'permission_callback' => fn() => current_user_can('publish_posts'),
            'args' => [
                'title' => ['type' => 'string', 'required' => true],
                'keyword' => ['type' => 'string', 'required' => true],
                'word_count' => ['type' => 'integer', 'required' => false, 'default' => 1500],
                'content_type' => ['type' => 'string', 'required' => false, 'default' => 'article'],
                'cluster_context' => ['type' => 'string', 'required' => false],
                'cluster_id' => ['type' => 'integer', 'required' => false],
                'cluster_role' => ['type' => 'string', 'required' => false],
                'cluster_map_id' => ['type' => 'integer', 'required' => false],
                'skip_cannibalism_check' => ['type' => 'boolean', 'required' => false, 'default' => false],
            ],
        ]);

        // Queue endpoints for background generation
        register_rest_route('sseo-ai/v1', '/clusters/queue', [
            'methods' => 'POST',
            'callback' => [$this, 'restQueueBulkGeneration'],
            'permission_callback' => fn() => current_user_can('publish_posts'),
        ]);

        register_rest_route('sseo-ai/v1', '/clusters/queue/(?P<queue_id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'restGetQueueStatus'],
            'permission_callback' => fn() => current_user_can('edit_posts'),
        ]);

        register_rest_route('sseo-ai/v1', '/clusters/queue/(?P<queue_id>\d+)/cancel', [
            'methods' => 'POST',
            'callback' => [$this, 'restCancelQueue'],
            'permission_callback' => fn() => current_user_can('publish_posts'),
        ]);

        // Async cluster map generation endpoints
        register_rest_route('sseo-ai/v1', '/clusters/generate-async', [
            'methods' => 'POST',
            'callback' => [$this, 'restGenerateClusterAsync'],
            'permission_callback' => fn() => current_user_can('edit_posts'),
        ]);

        register_rest_route('sseo-ai/v1', '/clusters/map-queue/(?P<queue_id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'restGetClusterMapQueueStatus'],
            'permission_callback' => fn() => current_user_can('edit_posts'),
        ]);

        register_rest_route('sseo-ai/v1', '/clusters/map-queue/(?P<queue_id>\d+)/cancel', [
            'methods' => 'POST',
            'callback' => [$this, 'restCancelClusterMapQueue'],
            'permission_callback' => fn() => current_user_can('edit_posts'),
        ]);

        // Manually trigger processing of a specific cluster map queue item
        // (useful when WP-Cron is unreliable or disabled)
        register_rest_route('sseo-ai/v1', '/clusters/map-queue/(?P<queue_id>\d+)/process', [
            'methods' => 'POST',
            'callback' => [$this, 'restProcessClusterMapQueueNow'],
            'permission_callback' => fn() => current_user_can('edit_posts'),
        ]);

        // Internal linking endpoint — re-link cluster posts after new content is added
        register_rest_route('sseo-ai/v1', '/clusters/(?P<cluster_id>\d+)/interlink', [
            'methods' => 'POST',
            'callback' => [$this, 'restInterlinkCluster'],
            'permission_callback' => fn() => current_user_can('edit_posts'),
        ]);
    }

    /**
     * Generate content for a cluster page and create WordPress draft
     */
    public function restGenerateClusterContent(\WP_REST_Request $request): array|\WP_Error
    {
        $title = sanitize_text_field($request->get_param('title'));
        $keyword = sanitize_text_field($request->get_param('keyword'));
        $wordCount = (int) ($request->get_param('word_count') ?: 1500);
        $contentType = sanitize_text_field($request->get_param('content_type') ?: 'article');
        $clusterContext = sanitize_textarea_field($request->get_param('cluster_context') ?: '');
        $scheduleDate = sanitize_text_field($request->get_param('schedule_date') ?: '');
        $clusterId = (int) ($request->get_param('cluster_id') ?: 0);
        $clusterRole = sanitize_text_field($request->get_param('cluster_role') ?: '');
        $clusterMapId = (int) ($request->get_param('cluster_map_id') ?: 0);
        $skipCannibalismCheck = (bool) ($request->get_param('skip_cannibalism_check') ?: false);

        if (empty($title) || empty($keyword)) {
            return new \WP_Error('missing_params', __('Title and keyword are required', 'ai-seo-client'), ['status' => 400]);
        }

        // 1.4 — Anti-cannibalisatie check
        if (!$skipCannibalismCheck) {
            $cannibalism = $this->checkCannibalism($keyword);
            if ($cannibalism !== null) {
                return new \WP_Error(
                    'cannibalism_detected',
                    sprintf(
                        __('A post already targets the keyword "%s": "%s" (ID: %d). Consider updating that post instead of creating a new one, or set skip_cannibalism_check to true.', 'ai-seo-client'),
                        $keyword,
                        $cannibalism['title'],
                        $cannibalism['post_id']
                    ),
                    ['status' => 409, 'existing_post' => $cannibalism]
                );
            }
        }

        // 1.3 — Use Content Brief for SERP-driven content generation
        $briefData = null;
        if ($this->contentBrief) {
            $briefData = $this->contentBrief->generateBrief($keyword);
            // Don't fail if brief generation fails — fall back to simple prompt
        }

        // Generate content using LLM (with brief data if available)
        $content = $this->generateClusterPageContent($title, $keyword, $wordCount, $contentType, $clusterContext, $briefData);
        
        if (is_wp_error($content)) {
            return $content;
        }

        // Determine post status and date based on scheduling
        $postData = [
            'post_title'   => $title,
            'post_content' => $content['content'],
            'post_type'    => 'post',
            'post_author'  => get_current_user_id(),
            'meta_input'   => [
                '_sseo_ai_title' => $title,
                '_sseo_ai_description' => $content['meta_description'] ?? '',
                '_sseo_ai_focus_keyphrase' => $keyword,
                '_sseo_ai_generated' => '1',
                '_sseo_ai_generated_date' => current_time('mysql'),
            ],
        ];

        if (!empty($scheduleDate) && strtotime(get_gmt_from_date($scheduleDate)) > time()) {
            $postData['post_status'] = 'future';
            $postData['post_date']   = $scheduleDate;
        } else {
            $postData['post_status'] = 'draft';
        }

        $postId = wp_insert_post($postData, true);

        if (is_wp_error($postId)) {
            return $postId;
        }
        $storedPost = get_post($postId);
        if (!$storedPost || trim(wp_strip_all_tags($storedPost->post_content)) === '') {
            return new \WP_Error('content_not_stored', __('Generated content could not be stored in the post', 'ai-seo-client'));
        }

        // 1.1 — Track cluster relationships in post meta
        if ($clusterId > 0) {
            update_post_meta($postId, '_sseo_ai_cluster_id', $clusterId);
            update_post_meta($postId, '_sseo_ai_cluster_role', $clusterRole);
            if ($clusterMapId > 0) {
                update_post_meta($postId, '_sseo_ai_cluster_map_id', $clusterMapId);
            }
        }

        // Add tags if available
        if (!empty($content['tags'])) {
            wp_set_post_tags($postId, $content['tags']);
        }

        // 1.1 — Inject internal links to other cluster posts that already exist
        if ($clusterId > 0) {
            $this->injectInternalLinks($postId, $clusterId, $keyword);
        }

        // Generate a featured image automatically when any image API key is configured
        $imageAttachmentId = null;
        if ($this->hasImageApiKey()) {
            $generator = new AIImageGenerator($this->settings, $this->llm);
            $imageAttachmentId = $generator->generateFeaturedImage($postId, 'photorealistic', '', 120);
        }

        // 1.5 — Post-generation quality pipeline
        $qualityScores = $this->runPostGenerationPipeline($postId, $keyword, $content['content']);

        // Run fact check (fail gracefully — does not block content generation)
        $factCheckReport = null;
        try {
            $factChecker = new FactChecker($this->llm);
            $factCheckReport = $factChecker->checkPost($postId);
            if (is_wp_error($factCheckReport)) {
                $factCheckReport = null;
            }
        } catch (\Exception $e) {
            $factCheckReport = null;
        }

        $result = [
            'success' => true,
            'post_id' => $postId,
            'edit_url' => get_edit_post_link($postId, ''),
            'view_url' => get_permalink($postId),
            'title' => $title,
            'word_count' => $content['word_count'] ?? 0,
        ];

        if ($factCheckReport !== null) {
            $result['fact_check'] = $factCheckReport;
        }

        if ($imageAttachmentId) {
            $result['image_attachment_id'] = $imageAttachmentId;
        }

        if ($qualityScores) {
            $result['quality_scores'] = $qualityScores;
        }

        if ($briefData && !is_wp_error($briefData)) {
            $result['brief_used'] = true;
        }

        return $result;
    }

    /**
     * Generate content for a cluster page
     * @param array|null $briefData Content Brief data from ContentBrief::generateBrief()
     */
    private function generateClusterPageContent(string $title, string $keyword, int $wordCount, string $contentType, string $clusterContext, ?array $briefData = null): array|\WP_Error
    {
        // Build SERP-informed section from brief data
        $briefSection = '';
        if ($briefData && !is_wp_error($briefData)) {
            $recommendedWords = $briefData['recommended_word_count'] ?? $wordCount;
            $headings = $briefData['recommended_headings'] ?? [];
            $questions = $briefData['recommended_questions'] ?? [];
            $entities = $briefData['recommended_entities'] ?? [];
            $lsi = $briefData['recommended_lsi'] ?? [];
            $intent = $briefData['search_intent'] ?? '';
            $angle = $briefData['content_angle'] ?? '';

            $headingsStr = !empty($headings) ? implode("\n- ", array_slice($headings, 0, 10)) : '';
            $questionsStr = !empty($questions) ? implode("\n- ", array_slice($questions, 0, 5)) : '';
            $entitiesStr = !empty($entities) ? implode(', ', array_slice($entities, 0, 15)) : '';
            $lsiStr = !empty($lsi) ? implode(', ', array_slice($lsi, 0, 15)) : '';

            // 3.1 — Research-backed citations from SERP sources
            $sources = $briefData['sources'] ?? [];
            $sourcesStr = '';
            if (!empty($sources)) {
                $sourceLines = [];
                foreach (array_slice($sources, 0, 5) as $src) {
                    $sourceLines[] = "- {$src['title']} ({$src['domain']}) — {$src['url']}";
                }
                $sourcesStr = implode("\n", $sourceLines);
            }

            $briefSection = "\n\nSERP Analysis (from top-ranking pages):";
            if ($intent) $briefSection .= "\nSearch Intent: {$intent}";
            if ($angle) $briefSection .= "\nUnique Angle: {$angle}";
            if ($recommendedWords) $briefSection .= "\nRecommended word count based on competitors: {$recommendedWords}";
            if ($headingsStr) $briefSection .= "\nRecommended headings:\n- {$headingsStr}";
            if ($questionsStr) $briefSection .= "\nQuestions to answer:\n- {$questionsStr}";
            if ($entitiesStr) $briefSection .= "\nEntities to include: {$entitiesStr}";
            if ($lsiStr) $briefSection .= "\nLSI/related terms to include: {$lsiStr}";
            if ($sourcesStr) $briefSection .= "\n\nAuthoritative sources to cite (reference these naturally in the content):\n{$sourcesStr}";
        }

        $prompt = <<<PROMPT
You are an expert SEO content writer. Create a comprehensive, SEO-optimized {$contentType} for the topic: "{$title}"

Target Keyword: {$keyword}
Target Word Count: {$wordCount} words

Business and editorial context:
{$clusterContext}{$briefSection}

Requirements:
1. Write in a professional, engaging tone
2. Include the target keyword naturally throughout the content (1-2% density)
3. Structure with proper H2 and H3 headings
4. Include an engaging introduction and conclusion
5. Add internal linking opportunities (suggest where to link to related content)
6. Include a FAQ section at the end
7. Write detailed, valuable content that satisfies search intent
8. If SERP analysis is provided above, follow the recommended structure, entities, and questions closely
9. If authoritative sources are listed above, cite them naturally in the content (e.g. "According to [Domain]..." or link to the source)

Return a JSON response in this exact format:
{
    "content": "Full HTML content with proper headings, paragraphs, lists",
    "meta_description": "SEO meta description (150-160 characters)",
    "tags": ["tag1", "tag2", "tag3"],
    "word_count": 1234
}

IMPORTANT: Return ONLY the JSON, no markdown formatting, no code blocks.
PROMPT;

        $response = $this->llm->generateText($prompt, ['max_tokens' => min(4000, $wordCount * 2), 'use_case' => 'content_generation']);

        if (is_wp_error($response)) {
            return $response;
        }

        // Parse JSON response — LLMs often wrap JSON in markdown code blocks
        $rawResponse = trim($response);
        if (preg_match('/```(?:json)?\s*(.+?)\s*```/s', $rawResponse, $m)) {
            $rawResponse = trim($m[1]);
        }

        $data = json_decode($rawResponse, true);

        if ($data && isset($data['content'])) {
            // Valid JSON received — verify content is not empty
            $plainContent = trim(wp_strip_all_tags((string) $data['content']));
            if ($plainContent === '' || str_word_count($plainContent) < 100) {
                return new \WP_Error('empty_content', __('AI returned empty or incomplete content for this post', 'ai-seo-client'));
            }
            return $data;
        }

        // JSON parsing failed. If the response looks like JSON, return an error
        // so the queue can retry instead of storing raw JSON as post content.
        $looksLikeJson = (strpos(trim($rawResponse), '{') === 0 || strpos(trim($rawResponse), '[') === 0);
        if ($looksLikeJson) {
            return new \WP_Error('invalid_json', __('AI returned malformed JSON response', 'ai-seo-client'));
        }

        // Response is not JSON — treat it as HTML content directly
        $plainContent = trim(wp_strip_all_tags($rawResponse));
        $actualWordCount = str_word_count($plainContent);
        if ($plainContent === '' || $actualWordCount < 100) {
            return new \WP_Error('empty_content', __('AI returned empty or incomplete content for this post', 'ai-seo-client'));
        }
        return [
            'content' => $rawResponse,
            'meta_description' => substr($plainContent, 0, 160),
            'tags' => [$keyword],
            'word_count' => $actualWordCount,
        ];
    }

    /**
     * Check whether any image generation API key is configured (generic or provider-specific).
     * Used to decide whether to attempt featured image generation.
     */
    private function hasImageApiKey(): bool
    {
        $imageApi = get_option('sseo_ai_client_image_api', []);
        if (!is_array($imageApi)) {
            return false;
        }
        return !empty($imageApi['key'])
            || !empty($imageApi['openrouter_key'])
            || !empty($imageApi['openai_key'])
            || !empty($imageApi['stability_key'])
            || !empty($imageApi['openart_key']);
    }

    /**
     * 1.4 — Check for keyword cannibalism: is there already a post targeting this keyword?
     * Returns existing post data if found, null otherwise.
     */
    private function checkCannibalism(string $keyword): ?array
    {
        $normalizedKeyword = strtolower(trim($keyword));

        // Check by exact focus keyphrase match
        $existingPosts = get_posts([
            'post_type' => 'post',
            'post_status' => ['publish', 'draft', 'future', 'pending'],
            'posts_per_page' => 1,
            'meta_query' => [
                [
                    'key' => '_sseo_ai_focus_keyphrase',
                    'value' => $normalizedKeyword,
                    'compare' => 'LIKE',
                ],
            ],
        ]);

        if (!empty($existingPosts)) {
            $post = $existingPosts[0];
            $existingKeyword = strtolower(trim(get_post_meta($post->ID, '_sseo_ai_focus_keyphrase', true)));
            // Check similarity
            similar_text($existingKeyword, $normalizedKeyword, $percent);
            if ($percent >= 80) {
                return [
                    'post_id' => $post->ID,
                    'title' => $post->post_title,
                    'edit_url' => get_edit_post_link($post->ID, ''),
                    'focus_keyphrase' => get_post_meta($post->ID, '_sseo_ai_focus_keyphrase', true),
                    'similarity' => round($percent, 1),
                ];
            }
        }

        return null;
    }

    /**
     * 1.1 — Get all posts belonging to a cluster
     */
    private function getClusterPosts(int $clusterId, int $excludePostId = 0): array
    {
        $posts = get_posts([
            'post_type' => 'post',
            'post_status' => ['publish', 'draft', 'future', 'pending'],
            'posts_per_page' => 100,
            'meta_query' => [
                [
                    'key' => '_sseo_ai_cluster_id',
                    'value' => $clusterId,
                    'compare' => '=',
                ],
            ],
        ]);

        $result = [];
        foreach ($posts as $post) {
            if ($post->ID === $excludePostId) continue;
            $result[] = [
                'id' => $post->ID,
                'title' => $post->post_title,
                'url' => get_permalink($post->ID),
                'keyword' => get_post_meta($post->ID, '_sseo_ai_focus_keyphrase', true),
                'role' => get_post_meta($post->ID, '_sseo_ai_cluster_role', true),
            ];
        }
        return $result;
    }

    /**
     * 1.1 — Inject internal links into a post's content, linking to other cluster posts.
     * Scans for mentions of other cluster posts' keywords/titles and converts them to links.
     */
    private function injectInternalLinks(int $postId, int $clusterId, string $currentKeyword): void
    {
        $post = get_post($postId);
        if (!$post) return;

        $content = $post->post_content;
        $clusterPosts = $this->getClusterPosts($clusterId, $postId);
        if (empty($clusterPosts)) return;

        $changed = false;
        foreach ($clusterPosts as $clusterPost) {
            // Use the cluster post's keyword or title as anchor text
            $anchorCandidates = array_filter([
                $clusterPost['keyword'] ?? '',
                $clusterPost['title'] ?? '',
            ]);

            foreach ($anchorCandidates as $anchor) {
                if (empty($anchor) || strlen($anchor) < 4) continue;

                // Check if this anchor text appears in content and isn't already a link
                $pattern = '/\b(' . preg_quote($anchor, '/') . ')\b(?![^<]*>|[^<>]*<\/a>)/i';
                if (preg_match($pattern, $content)) {
                    // Only add first occurrence to avoid over-linking
                    $replacement = '<a href="' . esc_url($clusterPost['url']) . '">$1</a>';
                    $newContent = preg_replace($pattern, $replacement, $content, 1);
                    if ($newContent && $newContent !== $content) {
                        $content = $newContent;
                        $changed = true;
                    }
                    break; // Move to next cluster post
                }
            }
        }

        if ($changed) {
            // Update post content without triggering a full re-save cycle
            wp_update_post([
                'ID' => $postId,
                'post_content' => $content,
            ], false);
        }
    }

    /**
     * 1.5 — Post-generation quality pipeline
     * Runs TruSEO scoring, Smart Tags, FAQ Schema extraction, and OG meta generation.
     */
    private function runPostGenerationPipeline(int $postId, string $keyword, string $content): array
    {
        $scores = [];
        $post = get_post($postId);
        if (!$post) return $scores;

        // TruSEO score calculation
        if ($this->truSEO) {
            try {
                $score = $this->truSEO->calculateScore($post, $keyword);
                update_post_meta($postId, '_sseo_ai_score', $score);
                $scores['tru_seo'] = $score;
            } catch (\Throwable $e) {
                // Non-fatal: continue pipeline
            }
        }

        // Smart Tags auto-generation
        if ($this->smartTags) {
            try {
                $tags = $this->smartTags->generateTags($post);
                if (!empty($tags)) {
                    // Merge with any existing tags
                    $existingTags = wp_get_post_tags($postId, ['fields' => 'names']);
                    $allTags = array_unique(array_merge($existingTags, array_slice($tags, 0, 8)));
                    wp_set_post_tags($postId, $allTags);
                    $scores['tags_generated'] = count($tags);
                }
            } catch (\Throwable $e) {
                // Non-fatal
            }
        }

        // FAQ Schema extraction
        if ($this->faqSchema) {
            try {
                $faqs = $this->faqSchema->extractFAQs($postId);
                if (!empty($faqs)) {
                    update_post_meta($postId, '_sseo_ai_auto_faqs', $faqs);
                    $scores['faqs_extracted'] = count($faqs);
                }
            } catch (\Throwable $e) {
                // Non-fatal
            }
        }

        // Content Optimizer score (if available)
        if ($this->contentOptimizer) {
            try {
                $optimizerResult = $this->contentOptimizer->scoreContent($keyword, $content, $post->post_title, $postId);
                if (!is_wp_error($optimizerResult) && isset($optimizerResult['score'])) {
                    update_post_meta($postId, '_sseo_ai_optimizer_score', $optimizerResult['score']);
                    $scores['content_optimizer'] = $optimizerResult['score'];
                }
            } catch (\Throwable $e) {
                // Non-fatal
            }
        }

        // GEO content score (AI search citability)
        if ($this->geoScore) {
            try {
                $geoResult = $this->geoScore->scoreContent($content, $keyword, $postId);
                if (isset($geoResult['score'])) {
                    $scores['geo_score'] = $geoResult['score'];
                }
            } catch (\Throwable $e) {
                // Non-fatal
            }
        }

        return $scores;
    }

    /**
     * REST: Queue bulk generation for background processing (1.2)
     * Creates a queue entry and lets WP-Cron process items.
     */
    public function restQueueBulkGeneration(\WP_REST_Request $request): array|\WP_Error
    {
        $pages = $request->get_param('pages');
        $clusterId = (int) ($request->get_param('cluster_id') ?: 0);
        $clusterMapId = (int) ($request->get_param('cluster_map_id') ?: 0);
        $startDate = sanitize_text_field($request->get_param('start_date') ?: '');
        $gapDays = (int) ($request->get_param('gap_days') ?: 3);

        if (empty($pages) || !is_array($pages)) {
            return new \WP_Error('missing_pages', __('Pages array is required', 'ai-seo-client'), ['status' => 400]);
        }

        // Create queue entry
        $queues = get_option('sseo_ai_cluster_queues', []);
        $queueId = count($queues) + 1;

        $queueItems = [];
        $scheduleDate = $startDate ? new \DateTime($startDate) : new \DateTime('+1 day');

        foreach ($pages as $index => $page) {
            $itemScheduleDate = clone $scheduleDate;
            $itemScheduleDate->modify('+' . ($index * $gapDays) . ' days');

            $queueItems[] = [
                'title' => sanitize_text_field($page['title'] ?? ''),
                'keyword' => sanitize_text_field($page['keyword'] ?? ''),
                'word_count' => (int) ($page['word_count'] ?? 1500),
                'content_type' => sanitize_text_field($page['content_type'] ?? 'article'),
                'cluster_role' => sanitize_text_field($page['content_type'] ?? ''),
                'schedule_date' => $itemScheduleDate->format('Y-m-d H:i:s'),
                'status' => 'pending',
                'post_id' => null,
                'error' => null,
                'attempts' => 0,
            ];
        }

        $queue = [
            'id' => $queueId,
            'cluster_id' => $clusterId,
            'cluster_map_id' => $clusterMapId,
            'items' => $queueItems,
            'total' => count($queueItems),
            'completed' => 0,
            'failed' => 0,
            'status' => 'pending',
            'created_at' => current_time('mysql'),
            'started_at' => null,
            'completed_at' => null,
        ];

        $queues[] = $queue;
        update_option('sseo_ai_cluster_queues', $queues);

        // Schedule cron if not already scheduled
        if (!wp_next_scheduled('sseo_ai_process_cluster_queue')) {
            wp_schedule_event(time() + 60, 'sseo_ai_queue_interval', 'sseo_ai_process_cluster_queue');
        }

        return [
            'success' => true,
            'queue_id' => $queueId,
            'total_items' => count($queueItems),
            'message' => __('Queue created. Content will be generated in the background.', 'ai-seo-client'),
        ];
    }

    /**
     * REST: Get queue status (1.2)
     */
    public function restGetQueueStatus(\WP_REST_Request $request): array|\WP_Error
    {
        $queueId = (int) $request->get_param('queue_id');
        $queues = get_option('sseo_ai_cluster_queues', []);

        foreach ($queues as $queue) {
            if (($queue['id'] ?? 0) === $queueId) {
                $completed = 0;
                $failed = 0;
                $pending = 0;
                $items = [];

                foreach ($queue['items'] as $item) {
                    $status = $item['status'] ?? 'pending';
                    if ($status === 'completed') $completed++;
                    elseif ($status === 'failed') $failed++;
                    else $pending++;

                    $items[] = [
                        'title' => $item['title'],
                        'keyword' => $item['keyword'],
                        'status' => $status,
                        'post_id' => $item['post_id'],
                        'edit_url' => $item['post_id'] ? get_edit_post_link($item['post_id'], '') : null,
                        'error' => $item['error'],
                    ];
                }

                return [
                    'queue_id' => $queueId,
                    'status' => $queue['status'],
                    'total' => $queue['total'],
                    'completed' => $completed,
                    'failed' => $failed,
                    'pending' => $pending,
                    'items' => $items,
                    'created_at' => $queue['created_at'],
                    'completed_at' => $queue['completed_at'],
                ];
            }
        }

        return new \WP_Error('not_found', __('Queue not found', 'ai-seo-client'), ['status' => 404]);
    }

    /**
     * REST: Cancel a pending queue (1.2)
     */
    public function restCancelQueue(\WP_REST_Request $request): array|\WP_Error
    {
        $queueId = (int) $request->get_param('queue_id');
        $queues = get_option('sseo_ai_cluster_queues', []);

        foreach ($queues as &$queue) {
            if (($queue['id'] ?? 0) === $queueId) {
                $queue['status'] = 'cancelled';
                foreach ($queue['items'] as &$item) {
                    if ($item['status'] === 'pending') {
                        $item['status'] = 'cancelled';
                    }
                }
                update_option('sseo_ai_cluster_queues', $queues);
                return ['success' => true, 'message' => __('Queue cancelled', 'ai-seo-client')];
            }
        }

        return new \WP_Error('not_found', __('Queue not found', 'ai-seo-client'), ['status' => 404]);
    }

    /**
     * REST: Re-run internal linking for all posts in a cluster (1.1)
     */
    public function restInterlinkCluster(\WP_REST_Request $request): array|\WP_Error
    {
        $clusterId = (int) $request->get_param('cluster_id');
        if ($clusterId <= 0) {
            return new \WP_Error('missing_id', __('Cluster ID is required', 'ai-seo-client'), ['status' => 400]);
        }

        $clusterPosts = $this->getClusterPosts($clusterId);
        $linked = 0;

        foreach ($clusterPosts as $clusterPost) {
            $this->injectInternalLinks($clusterPost['id'], $clusterId, $clusterPost['keyword'] ?? '');
            $linked++;
        }

        return [
            'success' => true,
            'cluster_id' => $clusterId,
            'posts_processed' => $linked,
            'message' => sprintf(__('Internal links updated for %d posts', 'ai-seo-client'), $linked),
        ];
    }

    /**
     * 1.2 — Process queue items via WP-Cron callback.
     * Processes a limited number of items per run to avoid timeouts.
     */
    public function processQueueItems(): void
    {
        $queues = get_option('sseo_ai_cluster_queues', []);
        if (empty($queues)) return;

        $maxPerRun = (int) get_option('sseo_ai_queue_batch_size', 2);
        $processed = 0;
        $allDone = true;

        foreach ($queues as &$queue) {
            if ($queue['status'] !== 'pending' && $queue['status'] !== 'processing') continue;
            $queue['status'] = 'processing';
            if (!$queue['started_at']) {
                $queue['started_at'] = current_time('mysql');
            }

            foreach ($queue['items'] as &$item) {
                if ($item['status'] !== 'pending') continue;
                if ($processed >= $maxPerRun) {
                    $allDone = false;
                    break;
                }

                $item['status'] = 'processing';
                $item['attempts'] = ($item['attempts'] ?? 0) + 1;

                try {
                    // Generate content for this item
                    $content = $this->generateClusterPageContent(
                        $item['title'],
                        $item['keyword'],
                        $item['word_count'],
                        $item['content_type'],
                        (string) ($item['cluster_context'] ?? '')
                    );

                    if (is_wp_error($content)) {
                        throw new \Exception($content->get_error_message());
                    }

                    // Determine post status
                    $itemPostType = !empty($item['post_type']) && post_type_exists($item['post_type']) ? $item['post_type'] : 'post';
                    $postData = [
                        'post_title' => $item['title'],
                        'post_content' => $content['content'],
                        'post_type' => $itemPostType,
                        'post_author' => (int) ($item['author_id'] ?? 0) ?: (get_current_user_id() ?: 1),
                        'meta_input' => [
                            '_sseo_ai_title' => $item['title'],
                            '_sseo_ai_description' => $content['meta_description'] ?? '',
                            '_sseo_ai_focus_keyphrase' => $item['keyword'],
                            '_sseo_ai_generated' => '1',
                            '_sseo_ai_generated_date' => current_time('mysql'),
                            '_sseo_ai_cluster_id' => $queue['cluster_id'] ?? 0,
                            '_sseo_ai_cluster_role' => $item['cluster_role'] ?? '',
                        ],
                    ];

                    if (!empty($item['category_id']) && $itemPostType === 'post') {
                        $postData['post_category'] = [(int) $item['category_id']];
                    }
                    if (!empty($item['source'])) {
                        $postData['meta_input']['_sseo_ai_source'] = $item['source'];
                    }

                    $scheduleDate = $item['schedule_date'] ?? '';
                    $isFuture = !empty($scheduleDate) && strtotime(get_gmt_from_date($scheduleDate)) > time();
                    if (($item['publish_mode'] ?? 'schedule') === 'draft') {
                        // Draft-review mode (ApexFlow): keep as draft, remember the planned date.
                        $postData['post_status'] = 'draft';
                        if (!empty($scheduleDate)) {
                            $postData['meta_input']['_sseo_ai_planned_date'] = $scheduleDate;
                        }
                    } elseif ($isFuture) {
                        $postData['post_status'] = 'future';
                        $postData['post_date'] = $scheduleDate;
                    } else {
                        $postData['post_status'] = 'draft';
                    }

                    $postId = wp_insert_post($postData, true);

                    if (is_wp_error($postId)) {
                        throw new \Exception($postId->get_error_message());
                    }
                    $storedPost = get_post($postId);
                    if (!$storedPost || trim(wp_strip_all_tags($storedPost->post_content)) === '') {
                        throw new \Exception(__('Generated content could not be stored in the post', 'ai-seo-client'));
                    }

                    // Add tags
                    if (!empty($content['tags'])) {
                        wp_set_post_tags($postId, $content['tags']);
                    }

                    // Inject internal links
                    $clusterId = $queue['cluster_id'] ?? 0;
                    if ($clusterId > 0) {
                        $this->injectInternalLinks($postId, $clusterId, $item['keyword']);
                    }

                    // Quality pipeline
                    $this->runPostGenerationPipeline($postId, $item['keyword'], $content['content']);

                    // Featured image — generate when an image API key is configured and the
                    // queue item does not opt out (ApexFlow setting).
                    $wantsImage = !array_key_exists('featured_image', $item) || !empty($item['featured_image']);
                    if ($wantsImage && $this->hasImageApiKey()) {
                        $generator = new AIImageGenerator($this->settings, $this->llm);
                        $generator->generateFeaturedImage($postId, 'photorealistic', '', 120);
                    }

                    $item['status'] = 'completed';
                    $item['post_id'] = $postId;
                    $queue['completed'] = ($queue['completed'] ?? 0) + 1;
                } catch (\Throwable $e) {
                    $item['status'] = 'failed';
                    $item['error'] = $e->getMessage();
                    $queue['failed'] = ($queue['failed'] ?? 0) + 1;

                    // Retry once more on next run if attempts < 2
                    if ($item['attempts'] < 2) {
                        $item['status'] = 'pending';
                        $queue['failed'] = max(0, ($queue['failed'] ?? 0) - 1);
                    }
                }

                $processed++;
            }

            // Check if queue is complete
            $pendingItems = array_filter($queue['items'], fn($i) => $i['status'] === 'pending' || $i['status'] === 'processing');
            if (empty($pendingItems)) {
                $queue['status'] = 'completed';
                $queue['completed_at'] = current_time('mysql');
            } else {
                $allDone = false;
            }
        }

        update_option('sseo_ai_cluster_queues', $queues);

        // Clear cron if all queues are done
        if ($allDone) {
            $timestamp = wp_next_scheduled('sseo_ai_process_cluster_queue');
            if ($timestamp) {
                wp_clear_scheduled_hook('sseo_ai_process_cluster_queue');
            }
        }
    }

    /**
     * Generate a complete topic cluster / topical authority map.
     */
    public function generateCluster(string $topic, string $depth = 'standard', string $language = 'en'): array|\WP_Error
    {
        $subtopicCount = $depth === 'deep' ? '20-30' : '10-15';
        $supportingCount = $depth === 'deep' ? '3-5' : '2-3';

        // Language mapping for prompt
        $languageNames = [
            'en' => 'English',
            'nl' => 'Dutch',
            'de' => 'German',
            'fr' => 'French',
            'es' => 'Spanish',
            'it' => 'Italian',
            'pt' => 'Portuguese',
            'pl' => 'Polish',
        ];
        $langName = $languageNames[$language] ?? 'English';

        // Phase 1: Generate the cluster skeleton — pillar page, cluster names,
        // hub pages, internal linking strategy and content calendar.
        // This is a smaller completion (~2000 tokens) that completes faster
        // and is less likely to time out or produce truncated JSON.
        $skeletonPrompt = <<<PROMPT
You are a topical authority expert (like MarketMuse). Generate a topic cluster SKELETON for building topical authority around: "{$topic}"

IMPORTANT: ALL content must be in {$langName} language. Use the exact topic "{$topic}" as provided - do NOT translate it to English. Return all titles, descriptions, keywords, and strategy in {$langName}.

Create a pillar-cluster content architecture. Return JSON only (no markdown):
{{
    "pillar_page": {{
        "title": "Comprehensive pillar page title",
        "slug": "url-slug",
        "description": "What this pillar page covers",
        "target_keyword": "primary keyword",
        "target_word_count": 3000,
        "search_intent": "informational"
    }},
    "clusters": [
        {{
            "name": "Subtopic cluster name",
            "description": "What this cluster covers",
            "hub_page": {{
                "title": "Hub article title",
                "slug": "url-slug",
                "target_keyword": "cluster keyword",
                "target_word_count": 2000,
                "search_intent": "informational|transactional|commercial",
                "priority": "high|medium|low"
            }},
            "supporting_pages": []
        }}
    ],
    "internal_linking_strategy": [
        "Linking rule 1: Pillar links to all hub pages",
        "Linking rule 2: Hub pages link to their supporting pages and back to pillar"
    ],
    "content_calendar": [
        {{"week": 1, "action": "Write pillar page", "pages": ["pillar slug"]}},
        {{"week": 2, "action": "Write first hub pages", "pages": ["slug1", "slug2"]}}
    ],
    "total_pages": 25,
    "estimated_months": 3,
    "topical_authority_score_potential": 85
}}

Requirements:
- Generate {$subtopicCount} subtopic clusters
- Each cluster has 1 hub page (supporting_pages will be filled in later — leave as empty array [])
- Cover the topic comprehensively — leave no major subtopic unaddressed
- Include a mix of search intents (informational, transactional, commercial)
- Prioritize by search volume potential and strategic importance
- Internal linking strategy should create clear topical silos
- Content calendar should be realistic (2-4 pages per week)

Return ONLY valid JSON.
PROMPT;

        $skeletonResult = $this->llm->call($skeletonPrompt, null, 'seo_expert', 2500, [], 'keyword_research');
        if (is_wp_error($skeletonResult)) {
            return $skeletonResult;
        }

        $data = $this->parseClusterJson($skeletonResult['text'] ?? '');
        if (is_wp_error($data)) {
            // Retry once with a stricter prompt for reliability
            $retryPrompt = $skeletonPrompt . "\n\nIMPORTANT: Your previous response was not valid JSON. Return ONLY a valid JSON object starting with { and ending with }. No markdown, no code fences, no commentary.";
            $retryResult = $this->llm->call($retryPrompt, null, 'seo_expert', 2500, [], 'keyword_research');
            if (!is_wp_error($retryResult)) {
                $data = $this->parseClusterJson($retryResult['text'] ?? '');
            }
        }

        if (is_wp_error($data)) {
            return $data;
        }

        // Phase 2: Generate supporting pages for each cluster.
        // Send the cluster skeleton and ask the AI to fill in supporting pages.
        // This is a separate, smaller completion that is much less likely to time out.
        $clustersJson = json_encode($data['clusters'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $supportingPrompt = <<<PROMPT
You are a topical authority expert. For each cluster in the JSON below, generate {$supportingCount} supporting pages.

IMPORTANT: ALL content must be in {$langName} language.

Here are the clusters (each has a name, description, and hub_page):
{$clustersJson}

For each cluster, add a "supporting_pages" array with {$supportingCount} supporting page objects. Each supporting page:
{{
    "title": "Supporting article title",
    "slug": "url-slug",
    "target_keyword": "long-tail keyword",
    "target_word_count": 1200,
    "search_intent": "informational|transactional|commercial",
    "content_type": "guide|how-to|comparison|listicle|case-study|FAQ",
    "priority": "high|medium|low"
}}

Return a JSON array of clusters (same order as input) with the supporting_pages filled in:
[
    {{
        "name": "cluster name (same as input)",
        "supporting_pages": [ ... ]
    }}
]

Include a mix of search intents and content types. Return ONLY valid JSON.
PROMPT;

        $supportingResult = $this->llm->call($supportingPrompt, null, 'seo_expert', 2500, [], 'keyword_research');

        if (!is_wp_error($supportingResult)) {
            $supportingData = $this->parseSupportingPagesJson($supportingResult['text'] ?? '', $data['clusters'] ?? []);
            if (!is_wp_error($supportingData)) {
                $data['clusters'] = $supportingData;
                // Recalculate total_pages now that supporting pages are filled in
                $totalPages = 1; // pillar
                foreach ($data['clusters'] as $cluster) {
                    $totalPages += 1; // hub
                    $totalPages += count($cluster['supporting_pages'] ?? []);
                }
                $data['total_pages'] = $totalPages;
            }
            // If supporting page generation fails, keep the skeleton with empty
            // supporting_pages — the cluster map is still useful with hubs only.
        }

        $data['topic'] = $topic;
        $data['generated_at'] = current_time('mysql');
        $data['depth'] = $depth;

        return $data;
    }

    /**
     * Parse the supporting pages JSON returned by phase 2 and merge it into
     * the existing cluster skeleton. Maps supporting pages back to clusters
     * by cluster name (case-insensitive, trimmed).
     *
     * @param string $rawText Raw LLM response
     * @param array $skeletonClusters Clusters from phase 1 (with hub pages, empty supporting_pages)
     * @return array|\WP_Error The clusters array with supporting_pages filled in
     */
    private function parseSupportingPagesJson(string $rawText, array $skeletonClusters): array|\WP_Error
    {
        $text = $rawText;
        // Strip markdown code fences
        $text = preg_replace('/^```(?:json)?\s*\n?/i', '', trim($text));
        $text = preg_replace('/\n?```\s*$/', '', $text);

        // Extract JSON array
        $jsonStart = strpos($text, '[');
        $jsonEnd = strrpos($text, ']');
        if ($jsonStart !== false && $jsonEnd !== false && $jsonEnd > $jsonStart) {
            $text = substr($text, $jsonStart, $jsonEnd - $jsonStart + 1);
        }

        $parsed = json_decode(trim($text), true);
        if (!is_array($parsed)) {
            return new \WP_Error('supporting_parse_error', 'Could not parse supporting pages JSON');
        }

        // Build a lookup map: normalized cluster name => supporting pages
        $supportingMap = [];
        foreach ($parsed as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $name = trim($entry['name'] ?? '');
            $pages = $entry['supporting_pages'] ?? [];
            if (!empty($name) && is_array($pages)) {
                $supportingMap[strtolower($name)] = $pages;
            }
        }

        // Merge supporting pages back into the skeleton clusters
        foreach ($skeletonClusters as $idx => $cluster) {
            $clusterName = trim($cluster['name'] ?? '');
            $normalized = strtolower($clusterName);
            if (isset($supportingMap[$normalized])) {
                $skeletonClusters[$idx]['supporting_pages'] = $supportingMap[$normalized];
            }
        }

        return $skeletonClusters;
    }

    /**
     * Parse and validate the JSON returned by the LLM for a cluster map.
     * Strips markdown fences, extracts the JSON object, and validates structure.
     *
     * @return array|\WP_Error
     */
    private function parseClusterJson(string $rawText): array|\WP_Error
    {
        $text = $rawText;
        // Strip markdown code fences
        $text = preg_replace('/^```(?:json)?\s*\n?/i', '', trim($text));
        $text = preg_replace('/\n?```\s*$/', '', $text);

        // Try to extract JSON if there's extra text around it
        $jsonStart = strpos($text, '{');
        $jsonEnd = strrpos($text, '}');
        if ($jsonStart !== false && $jsonEnd !== false && $jsonEnd > $jsonStart) {
            $text = substr($text, $jsonStart, $jsonEnd - $jsonStart + 1);
        }

        $data = json_decode(trim($text), true);
        if (!$data || !isset($data['pillar_page'])) {
            return new \WP_Error(
                'parse_error',
                __('De gegenereerde topic cluster kon niet worden geparseerd. De AI retourneerde geen geldige JSON. Probeer het opnieuw of verklein de depth instelling.', 'ai-seo-client')
                    . ' Response: ' . substr($rawText, 0, 500)
            );
        }

        return $data;
    }

    /**
     * Audit existing site content against a topic cluster.
     * Identifies what content already exists and what gaps remain.
     */
    public function auditExistingContent(string $topic): array
    {
        // Search site for related content
        $postTypes = get_post_types(['public' => true]);
        unset($postTypes['attachment']);

        $words = array_filter(explode(' ', $topic), fn($w) => strlen($w) > 2);

        $existingContent = [];
        $allPosts = get_posts([
            'post_type' => array_values($postTypes),
            'post_status' => 'publish',
            'posts_per_page' => 200,
            'orderby' => 'date',
            'order' => 'DESC',
        ]);

        foreach ($allPosts as $post) {
            $titleLower = strtolower($post->post_title);
            $contentLower = strtolower(wp_strip_all_tags($post->post_content));
            $fullText = $titleLower . ' ' . $contentLower;

            // Check relevance using keyword matching
            $matchScore = 0;
            foreach ($words as $word) {
                $wordLower = strtolower($word);
                if (stripos($titleLower, $wordLower) !== false) $matchScore += 3;
                $matchScore += substr_count($contentLower, $wordLower);
            }

            // Also check focus keyphrase
            $keyphrase = get_post_meta($post->ID, '_sseo_ai_focus_keyphrase', true);
            if ($keyphrase && stripos(strtolower($keyphrase), strtolower($topic)) !== false) {
                $matchScore += 10;
            }

            if ($matchScore >= 3) {
                $seoScore = get_post_meta($post->ID, '_sseo_ai_score', true);
                $wordCount = str_word_count(wp_strip_all_tags($post->post_content));

                $existingContent[] = [
                    'id' => $post->ID,
                    'title' => $post->post_title,
                    'url' => get_permalink($post->ID),
                    'edit_url' => get_edit_post_link($post->ID, ''),
                    'type' => $post->post_type,
                    'date' => $post->post_date,
                    'word_count' => $wordCount,
                    'seo_score' => $seoScore !== '' ? (int) $seoScore : null,
                    'focus_keyphrase' => $keyphrase ?: null,
                    'relevance_score' => $matchScore,
                ];
            }
        }

        // Sort by relevance
        usort($existingContent, fn($a, $b) => $b['relevance_score'] <=> $a['relevance_score']);

        // Calculate coverage stats
        $totalWords = array_sum(array_column($existingContent, 'word_count'));
        $avgScore = 0;
        $scoredPosts = array_filter($existingContent, fn($p) => $p['seo_score'] !== null);
        if (!empty($scoredPosts)) {
            $avgScore = (int) round(array_sum(array_column($scoredPosts, 'seo_score')) / count($scoredPosts));
        }

        return [
            'topic' => $topic,
            'existing_content' => array_slice($existingContent, 0, 50),
            'stats' => [
                'total_pages' => count($existingContent),
                'total_words' => $totalWords,
                'avg_seo_score' => $avgScore,
                'has_pillar' => count($existingContent) > 0 && $existingContent[0]['word_count'] >= 2000,
            ],
        ];
    }

    // Persistence — save/load clusters in options
    public function restSaveCluster(\WP_REST_Request $request): array
    {
        $cluster = $request->get_param('cluster');
        $clusters = get_option('aiseo_topic_clusters', []);

        $cluster['saved_at'] = current_time('mysql');
        $cluster['id'] = count($clusters) + 1;
        $clusters[] = $cluster;

        update_option('aiseo_topic_clusters', $clusters);
        return ['success' => true, 'id' => $cluster['id']];
    }

    public function restListClusters(\WP_REST_Request $request): array
    {
        return get_option('aiseo_topic_clusters', []);
    }

    public function restDeleteCluster(\WP_REST_Request $request): array
    {
        $id = (int) $request->get_param('id');
        $clusters = get_option('aiseo_topic_clusters', []);
        $clusters = array_values(array_filter($clusters, fn($c) => ($c['id'] ?? 0) !== $id));
        update_option('aiseo_topic_clusters', $clusters);
        return ['success' => true];
    }

    public function restGetCluster(\WP_REST_Request $request): array|\WP_Error
    {
        $id = (int) $request->get_param('id');
        $clusters = get_option('aiseo_topic_clusters', []);
        
        foreach ($clusters as $cluster) {
            if (($cluster['id'] ?? 0) === $id) {
                return $cluster;
            }
        }
        
        return new \WP_Error('not_found', 'Cluster not found', ['status' => 404]);
    }

    // REST handlers
    public function restGenerateCluster(\WP_REST_Request $request): array|\WP_Error
    {
        return $this->generateCluster(
            sanitize_text_field($request->get_param('topic')),
            sanitize_text_field($request->get_param('depth') ?: 'standard'),
            sanitize_text_field($request->get_param('language') ?: 'en')
        );
    }

    public function restAuditExistingContent(\WP_REST_Request $request): array
    {
        return $this->auditExistingContent(sanitize_text_field($request->get_param('topic')));
    }

    /**
     * REST: Queue a cluster map for async background generation.
     * Returns immediately with a queue_id; the result is stored later.
     */
    public function restGenerateClusterAsync(\WP_REST_Request $request): array|\WP_Error
    {
        $topic = sanitize_text_field($request->get_param('topic'));
        $depth = sanitize_text_field($request->get_param('depth') ?: 'standard');
        $language = sanitize_text_field($request->get_param('language') ?: 'en');

        if (empty($topic)) {
            return new \WP_Error('missing_topic', __('Topic is required', 'ai-seo-client'), ['status' => 400]);
        }

        if (!in_array($depth, ['standard', 'deep'], true)) {
            $depth = 'standard';
        }

        $queues = get_option('sseo_ai_cluster_map_queues', []);
        $queueId = count($queues) + 1;

        $queue = [
            'id' => $queueId,
            'topic' => $topic,
            'depth' => $depth,
            'language' => $language,
            'status' => 'pending',
            'result' => null,
            'error' => null,
            'created_at' => current_time('mysql'),
            'started_at' => null,
            'completed_at' => null,
        ];

        $queues[] = $queue;
        update_option('sseo_ai_cluster_map_queues', $queues);

        if (!wp_next_scheduled('sseo_ai_process_cluster_map_queue')) {
            wp_schedule_event(time() + 60, 'sseo_ai_queue_interval', 'sseo_ai_process_cluster_map_queue');
        }

        // Trigger WP-Cron immediately so the queue starts processing without
        // waiting for the next page load to spawn the cron.
        if (function_exists('spawn_cron')) {
            spawn_cron();
        }

        return [
            'success' => true,
            'queue_id' => $queueId,
            'status' => 'pending',
            'message' => __('Cluster map generation queued. Poll /clusters/map-queue/{queue_id} for status.', 'ai-seo-client'),
        ];
    }

    /**
     * REST: Get status of an async cluster map queue.
     */
    public function restGetClusterMapQueueStatus(\WP_REST_Request $request): array|\WP_Error
    {
        $queueId = (int) $request->get_param('queue_id');
        $queues = get_option('sseo_ai_cluster_map_queues', []);

        foreach ($queues as $queue) {
            if (($queue['id'] ?? 0) === $queueId) {
                return [
                    'queue_id' => $queueId,
                    'status' => $queue['status'],
                    'topic' => $queue['topic'],
                    'depth' => $queue['depth'],
                    'language' => $queue['language'],
                    'result' => $queue['result'],
                    'error' => $queue['error'],
                    'created_at' => $queue['created_at'],
                    'completed_at' => $queue['completed_at'],
                ];
            }
        }

        return new \WP_Error('not_found', __('Cluster map queue not found', 'ai-seo-client'), ['status' => 404]);
    }

    /**
     * REST: Cancel a pending cluster map queue.
     */
    public function restCancelClusterMapQueue(\WP_REST_Request $request): array|\WP_Error
    {
        $queueId = (int) $request->get_param('queue_id');
        $queues = get_option('sseo_ai_cluster_map_queues', []);

        foreach ($queues as &$queue) {
            if (($queue['id'] ?? 0) === $queueId) {
                if ($queue['status'] === 'pending') {
                    $queue['status'] = 'cancelled';
                    update_option('sseo_ai_cluster_map_queues', $queues);
                    return ['success' => true, 'message' => __('Cluster map queue cancelled', 'ai-seo-client')];
                }
                return new \WP_Error('not_cancelable', __('Only pending queues can be cancelled', 'ai-seo-client'), ['status' => 409]);
            }
        }

        return new \WP_Error('not_found', __('Cluster map queue not found', 'ai-seo-client'), ['status' => 404]);
    }

    /**
     * REST: Manually process a specific cluster map queue item immediately.
     * Useful when WP-Cron is unreliable or disabled — the admin can trigger
     * processing from the UI without waiting for the next cron tick.
     */
    public function restProcessClusterMapQueueNow(\WP_REST_Request $request): array|\WP_Error
    {
        $queueId = (int) $request->get_param('queue_id');
        $queues = get_option('sseo_ai_cluster_map_queues', []);

        $found = false;
        foreach ($queues as $queue) {
            if (($queue['id'] ?? 0) === $queueId) {
                $found = true;
                if (!in_array($queue['status'], ['pending', 'processing'], true)) {
                    return new \WP_Error(
                        'not_processable',
                        sprintf(__('Queue status is "%s" — only pending/processing queues can be processed.', 'ai-seo-client'), $queue['status']),
                        ['status' => 409]
                    );
                }
                break;
            }
        }

        if (!$found) {
            return new \WP_Error('not_found', __('Cluster map queue not found', 'ai-seo-client'), ['status' => 404]);
        }

        // Process the queue synchronously (this call blocks until done)
        $this->processClusterMapQueueItems();

        // Re-read the queue to get the updated status
        $queues = get_option('sseo_ai_cluster_map_queues', []);
        foreach ($queues as $queue) {
            if (($queue['id'] ?? 0) === $queueId) {
                return [
                    'success' => true,
                    'queue_id' => $queueId,
                    'status' => $queue['status'],
                    'result' => $queue['result'],
                    'error' => $queue['error'],
                    'completed_at' => $queue['completed_at'] ?? null,
                ];
            }
        }

        return ['success' => true, 'queue_id' => $queueId, 'status' => 'unknown'];
    }

    /**
     * Process pending async cluster map queue items via WP-Cron.
     * Generates one map per run to avoid timeouts.
     *
     * On timeout, the queue is put back to "pending" (with an attempt counter)
     * so the next cron run retries it, rather than permanently failing.
     */
    public function processClusterMapQueueItems(): void
    {
        // Cluster map generation uses 600s timeout for the AI call chain,
        // so give the PHP process enough runway.
        if (function_exists('set_time_limit')) {
            @set_time_limit(600);
        }

        $queues = get_option('sseo_ai_cluster_map_queues', []);
        if (empty($queues)) return;

        $allDone = true;
        $maxAttempts = 3;

        foreach ($queues as &$queue) {
            if ($queue['status'] !== 'pending' && $queue['status'] !== 'processing') continue;

            $allDone = false;
            $queue['status'] = 'processing';
            if (!$queue['started_at']) {
                $queue['started_at'] = current_time('mysql');
            }

            $attempts = (int)($queue['attempts'] ?? 0);
            error_log(sprintf(
                'SSEO AI: Processing cluster map queue #%d (topic: %s, attempt: %d)',
                $queue['id'],
                $queue['topic'],
                $attempts + 1
            ));

            try {
                $result = $this->generateCluster($queue['topic'], $queue['depth'], $queue['language']);

                if (is_wp_error($result)) {
                    throw new \Exception($result->get_error_message(), 0);
                }

                // Persist the generated cluster map
                $clusters = get_option('aiseo_topic_clusters', []);
                $result['id'] = count($clusters) + 1;
                $result['saved_at'] = current_time('mysql');
                $result['queue_id'] = $queue['id'];
                $clusters[] = $result;
                update_option('aiseo_topic_clusters', $clusters);

                $queue['status'] = 'completed';
                $queue['result'] = $result;
                $queue['completed_at'] = current_time('mysql');
                error_log(sprintf('SSEO AI: Cluster map queue #%d completed successfully', $queue['id']));
            } catch (\Throwable $e) {
                $errorMsg = $e->getMessage();
                $isTimeout = stripos($errorMsg, 'timed out') !== false || stripos($errorMsg, 'timeout') !== false;
                $attempts = $attempts + 1;
                $queue['attempts'] = $attempts;

                if ($isTimeout && $attempts < $maxAttempts) {
                    // On timeout, put the queue back to pending so the next cron
                    // run retries it. Timeouts are often transient (slow model,
                    // rate limit, network hiccup) and a retry may succeed.
                    $queue['status'] = 'pending';
                    $queue['error'] = sprintf(
                        __('Timeout on attempt %d/%d. Will retry automatically.', 'ai-seo-client'),
                        $attempts,
                        $maxAttempts
                    );
                    error_log(sprintf('SSEO AI: Cluster map queue #%d timed out (attempt %d/%d), will retry', $queue['id'], $attempts, $maxAttempts));
                } else {
                    $queue['status'] = 'failed';
                    $queue['error'] = $errorMsg;
                    $queue['completed_at'] = current_time('mysql');
                    error_log(sprintf('SSEO AI: Cluster map queue #%d failed: %s', $queue['id'], $errorMsg));
                }
            }

            // Only process one map per cron run to stay within time limits
            break;
        }

        update_option('sseo_ai_cluster_map_queues', $queues);

        if ($allDone) {
            $timestamp = wp_next_scheduled('sseo_ai_process_cluster_map_queue');
            if ($timestamp) {
                wp_clear_scheduled_hook('sseo_ai_process_cluster_map_queue');
            }
        }
    }

    /**
     * Render admin page
     */
    public function renderPage(): void
    {
        ?>
        <style>
            .wrap.sseo-ai-modern { margin: 0; padding: 0; font-family: Outfit, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
            .sseo-ai-header { background: linear-gradient(135deg, #379fd3 0%, #8f39ac 100%); color: #fff; padding: 30px 40px; margin: -10px -20px 0 -20px; }
            .sseo-ai-header h1 { font-size: 28px; font-weight: 700; color: #fff; margin: 0; }
            .sseo-ai-header p { margin: 10px 0 0 0; opacity: 0.8; }
            .sseo-ai-content { padding: 40px; background: linear-gradient(135deg, #379fd3 0%, #8f39ac 100%); min-height: calc(100vh - 150px); }
            .sseo-ai-dashboard-card { background: rgba(255, 255, 255, 0.95); border-radius: 12px; padding: 30px; box-shadow: 0 10px 15px -3px rgba(0,0,0,.1); }
            .tc-status-success { color: #16a34a; }
            .tc-status-error { color: #dc2626; }
        </style>
        <div class="wrap sseo-ai-modern">
            <div class="sseo-ai-header">
                <h1><?php esc_html_e('Topic Clusters & Topical Authority', 'ai-seo-client'); ?></h1>
                <p><?php esc_html_e('Build topical authority with pillar-cluster content maps. Plan comprehensive content strategies that establish you as the go-to resource on any topic.', 'ai-seo-client'); ?></p>
            </div>
            
            <div class="sseo-ai-content">
                <div style="max-width:1400px;">
                    <?php DashboardSorter::begin('ai-seo-topic-clusters'); ?>
                    <!-- Generator -->
                    <div class="postbox" style="padding:20px;" data-card-id="tc-generator">
                    <h2 style="margin-top:0;"><?php esc_html_e('Generate Topic Cluster', 'ai-seo-client'); ?></h2>
                    <div style="display:flex;gap:10px;align-items:end;">
                        <div style="flex:1;">
                            <label style="font-weight:600;display:block;margin-bottom:4px;"><?php esc_html_e('Core Topic', 'ai-seo-client'); ?></label>
                            <input type="text" id="tc-topic" class="large-text" placeholder="<?php esc_attr_e('e.g. WordPress SEO, email marketing, project management', 'ai-seo-client'); ?>">
                        </div>
                        <div>
                            <label style="font-weight:600;display:block;margin-bottom:4px;"><?php esc_html_e('Language', 'ai-seo-client'); ?></label>
                            <select id="tc-language" style="width:140px;">
                                <option value="nl">Nederlands</option>
                                <option value="en" selected>English</option>
                                <option value="de">Deutsch</option>
                                <option value="fr">Français</option>
                                <option value="es">Español</option>
                                <option value="it">Italiano</option>
                                <option value="pt">Português</option>
                                <option value="pl">Polski</option>
                            </select>
                        </div>
                        <div>
                            <label style="font-weight:600;display:block;margin-bottom:4px;"><?php esc_html_e('Depth', 'ai-seo-client'); ?></label>
                            <select id="tc-depth">
                                <option value="standard"><?php esc_html_e('Standard (10-15 clusters)', 'ai-seo-client'); ?></option>
                                <option value="deep"><?php esc_html_e('Deep (20-30 clusters)', 'ai-seo-client'); ?></option>
                            </select>
                        </div>
                        <button type="button" class="button button-primary" id="tc-generate" style="height:30px;"><?php esc_html_e('Generate Map', 'ai-seo-client'); ?></button>
                        <span id="tc-generate-spinner" class="spinner" style="float:none;margin:0 5px;"></span>
                        <span id="tc-generate-status" style="margin-left:8px;font-weight:600;"></span>
                        <button type="button" class="button" id="tc-audit" style="height:30px;"><?php esc_html_e('Audit Existing Content', 'ai-seo-client'); ?></button>
                    </div>
                </div>

                <!-- Audit Results -->
                <div id="tc-audit-result" style="display:none;margin-top:20px;"></div>

                <!-- Inline Error Message -->
                <div id="tc-error-msg" style="display:none;margin-top:20px;padding:15px 20px;background:#fee2e2;border:1px solid #dc2626;border-radius:8px;color:#991b1b;">
                    <strong>&#9888; <?php esc_html_e('Fout', 'ai-seo-client'); ?>:</strong>
                    <span id="tc-error-text"></span>
                    <button type="button" class="button button-small" style="float:right;" onclick="jQuery('#tc-error-msg').slideUp();">&times;</button>
                </div>

                <!-- Cluster Map -->
                <div id="tc-result" style="display:none;margin-top:20px;">
                    <!-- Overview -->
                    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:15px;margin-bottom:20px;">
                        <div class="postbox" style="padding:15px;text-align:center;">
                            <div id="tc-total-pages" style="font-size:28px;font-weight:bold;color:#379fd3;">0</div>
                            <div style="font-size:12px;color:#666;"><?php esc_html_e('Total Pages', 'ai-seo-client'); ?></div>
                        </div>
                        <div class="postbox" style="padding:15px;text-align:center;">
                            <div id="tc-clusters" style="font-size:28px;font-weight:bold;color:#059669;">0</div>
                            <div style="font-size:12px;color:#666;"><?php esc_html_e('Clusters', 'ai-seo-client'); ?></div>
                        </div>
                        <div class="postbox" style="padding:15px;text-align:center;">
                            <div id="tc-months" style="font-size:28px;font-weight:bold;color:#7c3aed;">0</div>
                            <div style="font-size:12px;color:#666;"><?php esc_html_e('Est. Months', 'ai-seo-client'); ?></div>
                        </div>
                        <div class="postbox" style="padding:15px;text-align:center;">
                            <div id="tc-authority" style="font-size:28px;font-weight:bold;color:#d97706;">0</div>
                            <div style="font-size:12px;color:#666;"><?php esc_html_e('Authority Potential', 'ai-seo-client'); ?></div>
                        </div>
                    </div>

                    <!-- Priority Legend -->
                    <div class="postbox" style="padding:15px;margin-bottom:20px;">
                        <h3 style="margin:0 0 10px 0;font-size:16px;"><?php esc_html_e('Priority Legend', 'ai-seo-client'); ?></h3>
                        <div style="display:flex;gap:20px;align-items:center;flex-wrap:wrap;font-size:13px;">
                            <span style="display:flex;align-items:center;gap:6px;"><span style="width:12px;height:12px;border-radius:50%;background:#16a34a;"></span> <?php esc_html_e('High — high search volume or strong strategic value', 'ai-seo-client'); ?></span>
                            <span style="display:flex;align-items:center;gap:6px;"><span style="width:12px;height:12px;border-radius:50%;background:#d97706;"></span> <?php esc_html_e('Medium — moderate priority', 'ai-seo-client'); ?></span>
                            <span style="display:flex;align-items:center;gap:6px;"><span style="width:12px;height:12px;border-radius:50%;background:#6b7280;"></span> <?php esc_html_e('Low — lower priority / nice to have', 'ai-seo-client'); ?></span>
                        </div>
                    </div>

                    <!-- Pillar Page -->
                    <div id="tc-pillar" class="postbox" style="padding:20px;border-left:4px solid #379fd3;"></div>

                    <!-- Cluster Grid -->
                    <div id="tc-cluster-grid" style="margin-top:20px;"></div>

                    <!-- Linking Strategy -->
                    <div class="postbox" style="padding:15px;margin-top:20px;">
                        <h3 style="margin-top:0;"><?php esc_html_e('Internal Linking Strategy', 'ai-seo-client'); ?></h3>
                        <ul id="tc-linking" style="list-style:none;padding:0;"></ul>
                    </div>

                    <!-- Content Calendar -->
                    <div class="postbox" style="padding:15px;margin-top:20px;">
                        <h3 style="margin-top:0;"><?php esc_html_e('Content Calendar', 'ai-seo-client'); ?></h3>
                        <div id="tc-calendar" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:10px;"></div>
                    </div>

                    <!-- Review & Bulk Generate Section -->
                    <div class="postbox" style="padding:20px;margin-top:20px;background:linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);border:2px solid #16a34a;">
                        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:15px;">
                            <h3 style="margin:0;color:#166534;">📋 <?php esc_html_e('Review & Generate Content', 'ai-seo-client'); ?></h3>
                            <div>
                                <button type="button" class="button" id="tc-toggle-review" style="margin-right:10px;">
                                    <?php esc_html_e('Review All Pages', 'ai-seo-client'); ?>
                                </button>
                                <button type="button" class="button button-primary" id="tc-save"><?php esc_html_e('Save This Cluster Map', 'ai-seo-client'); ?></button>
                                <span style="margin-left:10px;display:inline-flex;align-items:center;gap:5px;">
                                    <label style="font-size:12px;color:#166534;"><?php esc_html_e('Start:', 'ai-seo-client'); ?></label>
                                    <input type="date" id="tc-schedule-start" style="width:140px;" />
                                    <label style="font-size:12px;color:#166534;margin-left:5px;"><?php esc_html_e('Gap (days):', 'ai-seo-client'); ?></label>
                                    <input type="number" id="tc-schedule-gap" value="3" min="1" max="14" style="width:60px;" />
                                </span>
                                <button type="button" class="button" id="tc-sync-calendar" style="margin-left:5px;"><?php esc_html_e('Sync to Content Calendar', 'ai-seo-client'); ?></button>
                            </div>
                        </div>
                        <p style="margin:0;color:#166534;font-size:13px;">
                            <?php esc_html_e('Review all pages, select which to generate, and create content drafts in bulk.', 'ai-seo-client'); ?>
                        </p>
                    </div>

                    <!-- Pages Review Table (Hidden by default) -->
                    <div id="tc-review-section" style="display:none;margin-top:20px;">
                        <div class="postbox" style="padding:20px;">
                            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:10px;">
                                <h3 style="margin:0;">📄 <?php esc_html_e('All Pages in Cluster', 'ai-seo-client'); ?></h3>
                                <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                                    <div style="display:flex;gap:8px;align-items:center;">
                                        <label style="font-size:12px;white-space:nowrap;"><?php esc_html_e('Start date', 'ai-seo-client'); ?></label>
                                        <input type="date" id="tc-schedule-start" class="small-text" style="font-size:12px;">
                                        <label style="font-size:12px;white-space:nowrap;"><?php esc_html_e('Gap (days)', 'ai-seo-client'); ?></label>
                                        <input type="number" id="tc-schedule-gap" value="3" min="1" class="small-text" style="width:60px;font-size:12px;">
                                    </div>
                                    <button type="button" class="button" id="tc-select-all"><?php esc_html_e('Select All', 'ai-seo-client'); ?></button>
                                    <button type="button" class="button" id="tc-deselect-all"><?php esc_html_e('Deselect All', 'ai-seo-client'); ?></button>
                                    <button type="button" class="button button-primary" id="tc-bulk-generate" style="background:#16a34a;border-color:#16a34a;">
                                        <?php esc_html_e('Generate Selected', 'ai-seo-client'); ?> (<span id="tc-selected-count">0</span>)
                                    </button>
                                    <button type="button" class="button button-primary" id="tc-generate-all" style="background:#0d6efd;border-color:#0d6efd;margin-left:5px;">
                                        <?php esc_html_e('Generate All', 'ai-seo-client'); ?>
                                    </button>
                                </div>
                            </div>
                            
                            <!-- Stats -->
                            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:15px;margin-bottom:20px;">
                                <div style="padding:15px;background:#f8fafc;border-radius:8px;text-align:center;">
                                    <div id="tc-review-total" style="font-size:24px;font-weight:bold;color:#379fd3;">0</div>
                                    <div style="font-size:12px;color:#64748b;"><?php esc_html_e('Total Pages', 'ai-seo-client'); ?></div>
                                </div>
                                <div style="padding:15px;background:#f8fafc;border-radius:8px;text-align:center;">
                                    <div id="tc-review-selected" style="font-size:24px;font-weight:bold;color:#16a34a;">0</div>
                                    <div style="font-size:12px;color:#64748b;"><?php esc_html_e('Selected', 'ai-seo-client'); ?></div>
                                </div>
                                <div style="padding:15px;background:#f8fafc;border-radius:8px;text-align:center;">
                                    <div id="tc-review-words" style="font-size:24px;font-weight:bold;color:#7c3aed;">0</div>
                                    <div style="font-size:12px;color:#64748b;"><?php esc_html_e('Total Words', 'ai-seo-client'); ?></div>
                                </div>
                                <div style="padding:15px;background:#f8fafc;border-radius:8px;text-align:center;">
                                    <div id="tc-review-est-cost" style="font-size:24px;font-weight:bold;color:#d97706;">$0</div>
                                    <div style="font-size:12px;color:#64748b;"><?php esc_html_e('Est. API Cost', 'ai-seo-client'); ?></div>
                                </div>
                            </div>

                            <!-- Pages Table -->
                            <div style="max-height:600px;overflow-y:auto;border:1px solid #e2e8f0;border-radius:8px;">
                                <table class="wp-list-table widefat striped" style="margin:0;border:none;" id="tc-pages-table">
                                    <thead style="position:sticky;top:0;background:#f8fafc;z-index:10;">
                                        <tr>
                                            <th style="width:40px;text-align:center;"><input type="checkbox" id="tc-select-all-checkbox"></th>
                                            <th><?php esc_html_e('Page Title', 'ai-seo-client'); ?></th>
                                            <th style="width:150px;"><?php esc_html_e('Type', 'ai-seo-client'); ?></th>
                                            <th style="width:180px;"><?php esc_html_e('Target Keyword', 'ai-seo-client'); ?></th>
                                            <th style="width:100px;"><?php esc_html_e('Words', 'ai-seo-client'); ?></th>
                                            <th style="width:100px;"><?php esc_html_e('Priority', 'ai-seo-client'); ?></th>
                                            <th style="width:120px;"><?php esc_html_e('Status', 'ai-seo-client'); ?></th>
                                            <th style="width:50px;text-align:center;"><?php esc_html_e('Delete', 'ai-seo-client'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody id="tc-pages-tbody">
                                        <!-- Populated by JS -->
                                    </tbody>
                                </table>
                            </div>

                            <!-- Bulk Progress -->
                            <div id="tc-bulk-progress" style="display:none;margin-top:20px;padding:20px;background:#f0fdf4;border-radius:8px;">
                                <h4 style="margin:0 0 15px 0;color:#166534;">⏳ <?php esc_html_e('Generating Content in Background...', 'ai-seo-client'); ?></h4>
                                <p style="margin:0 0 10px 0;font-size:13px;color:#166534;"><?php esc_html_e('Content is generated via WP-Cron. You can close this page — check back later or view your drafts/scheduled posts.', 'ai-seo-client'); ?></p>
                                <div style="margin:0 0 15px 0;padding:15px;background:rgba(22,163,74,0.08);border-radius:8px;border:1px solid #16a34a;">
                                    <p style="margin:0 0 10px 0;font-size:14px;color:#166534;font-style:italic;">
                                        🏝️ <?php esc_html_e('Sit back and relax or book your next vacation to Bora Bora', 'ai-seo-client'); ?>
                                    </p>
                                    <a href="https://www.booking.com/searchresults.nl.html?ss=Bora+Bora%2C+Frans-Polynesi%C3%AB&efdco=1&label=gen173nr-10CAEoggI46AdIM1gEaKkBiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALu2PvTBsACAdICJGQ0ZmUxYWQ4LWFjNGYtNGYwOS05ODYzLWYyYjAxYmRkZDM4ONgCAeACAQ&aid=304142&lang=nl&sb=1&src_elem=sb&src=index&dest_id=3978&dest_type=region&ac_position=0&ac_click_type=b&ac_langcode=nl&ac_suggestion_list_length=5&search_selected=true&search_pageview_id=a33848f7b86208f0&ac_meta=GhBhMzM4NDhmN2I4NjIwOGYwIAAoATICbmw6CWJvcmEgYm9yYQ%3D%3D&group_adults=2&no_rooms=1&group_children=0"
                                       target="_blank" rel="noopener noreferrer"
                                       class="button button-primary"
                                       style="background:#16a34a;border-color:#16a34a;text-decoration:none;">
                                        <?php esc_html_e('Book your Bora Bora trip', 'ai-seo-client'); ?> →
                                    </a>
                                </div>
                                <div style="background:#e2e8f0;border-radius:10px;height:24px;overflow:hidden;margin-bottom:10px;">
                                    <div id="tc-progress-bar" style="background:linear-gradient(90deg,#16a34a,#22c55e);height:100%;width:0%;transition:width 0.3s ease;display:flex;align-items:center;justify-content:center;color:#fff;font-size:12px;font-weight:600;">0%</div>
                                </div>
                                <div id="tc-progress-text" style="font-size:13px;color:#64748b;"><?php esc_html_e('Preparing...', 'ai-seo-client'); ?></div>
                                <div id="tc-progress-log" style="margin-top:15px;max-height:200px;overflow-y:auto;font-family:monospace;font-size:11px;background:#fff;padding:10px;border-radius:4px;border:1px solid #e2e8f0;"></div>
                            </div>

                            <!-- Results -->
                            <div id="tc-bulk-results" style="display:none;margin-top:20px;"></div>
                        </div>
                    </div>
                </div>

                    <!-- Saved Clusters -->
                    <div class="postbox" style="padding:15px;margin-top:30px;">
                        <h3 style="margin-top:0;"><?php esc_html_e('Saved Cluster Maps', 'ai-seo-client'); ?></h3>
                        <div id="tc-saved-list"></div>
                    </div>
                    <?php DashboardSorter::end('ai-seo-topic-clusters'); ?>
                </div>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            var currentCluster = null;

            // Load saved clusters
            function loadSaved() {
                wp.apiFetch({ path: '/sseo-ai/v1/clusters/list' }).then(function(list) {
                    if (!list || !list.length) {
                        $('#tc-saved-list').html('<p style="color:#999;"><?php echo esc_js(__('No saved clusters yet.', 'ai-seo-client')); ?></p>');
                        return;
                    }
                    var html = '<table class="wp-list-table widefat striped" style="font-size:13px;"><thead><tr><th>Topic</th><th>Pages</th><th>Clusters</th><th>Date</th><th style="width:120px;"></th></tr></thead><tbody>';
                    list.forEach(function(c) {
                        html += '<tr><td><strong>' + (c.topic || '—') + '</strong></td>' +
                            '<td>' + (c.total_pages || '—') + '</td>' +
                            '<td>' + ((c.clusters||[]).length) + '</td>' +
                            '<td>' + (c.saved_at || c.generated_at || '—') + '</td>' +
                            '<td>' +
                            '<button class="button button-small tc-view-saved" data-id="' + c.id + '" style="margin-right:5px;">View</button>' +
                            '<button class="button button-small tc-delete-saved" data-id="' + c.id + '">Delete</button>' +
                            '</td></tr>';
                    });
                    html += '</tbody></table>';
                    $('#tc-saved-list').html(html);
                });
            }
            loadSaved();

            $(document).on('click', '.tc-delete-saved', function() {
                var id = $(this).data('id');
                if (!confirm('Delete?')) return;
                wp.apiFetch({ path: '/sseo-ai/v1/clusters/' + id, method: 'DELETE' }).then(loadSaved);
            });

            // View saved cluster
            $(document).on('click', '.tc-view-saved', function() {
                var id = $(this).data('id');
                wp.apiFetch({ path: '/sseo-ai/v1/clusters/' + id }).then(function(data) {
                    currentCluster = data;
                    $('#tc-topic').val(data.topic || '');
                    renderCluster(data);
                    $('#tc-result').show();
                    // Scroll to result
                    $('html, body').animate({
                        scrollTop: $('#tc-result').offset().top - 100
                    }, 500);
                }).catch(function(err) {
                    alert(err.message || 'Failed to load cluster');
                });
            });

            // Generate — async queue with polling
            $('#tc-generate').on('click', function() {
                var topic = $('#tc-topic').val().trim();
                if (!topic) return;
                var btn = $(this);
                var status = $('#tc-generate-status');
                var spinner = $('#tc-generate-spinner');
                var depth = $('#tc-depth').val();
                var language = $('#tc-language').val();

                btn.prop('disabled', true).text('<?php echo esc_js(__('Queueing...', 'ai-seo-client')); ?>');
                spinner.addClass('is-active');
                status.text('').removeClass('tc-status-error tc-status-success');
                if (typeof sseoShowLoader === 'function') sseoShowLoader();

                wp.apiFetch({
                    path: '/sseo-ai/v1/clusters/generate-async',
                    method: 'POST',
                    data: { topic: topic, depth: depth, language: language }
                }).then(function(res) {
                    if (!res.queue_id) {
                        throw new Error('<?php echo esc_js(__('Queue ID missing', 'ai-seo-client')); ?>');
                    }
                    status.text('<?php echo esc_js(__('Queued', 'ai-seo-client')); ?> #' + res.queue_id);
                    btn.text('<?php echo esc_js(__('Generating...', 'ai-seo-client')); ?>');

                    var attempts = 0;
                    var maxAttempts = 120; // 10 minutes at 5 second intervals
                    var pendingPolls = 0; // count consecutive "pending" polls
                    var pollInterval = setInterval(function() {
                        attempts++;
                        if (attempts > maxAttempts) {
                            clearInterval(pollInterval);
                            spinner.removeClass('is-active');
                            btn.prop('disabled', false).text('<?php echo esc_js(__('Generate Map', 'ai-seo-client')); ?>');
                            status.addClass('tc-status-error').html('<?php echo esc_js(__('Timeout waiting for cluster map', 'ai-seo-client')); ?> <button type="button" class="button button-small tc-process-now" data-queue="' + res.queue_id + '" style="margin-left:10px;"><?php echo esc_js(__('Process now', 'ai-seo-client')); ?></button>');
                            if (typeof sseoHideLoader === 'function') sseoHideLoader();
                            return;
                        }

                        wp.apiFetch({
                            path: '/sseo-ai/v1/clusters/map-queue/' + res.queue_id,
                            method: 'GET'
                        }).then(function(state) {
                            if (state.status === 'completed' && state.result) {
                                clearInterval(pollInterval);
                                currentCluster = state.result;
                                renderCluster(state.result);
                                $('#tc-result').show();
                                spinner.removeClass('is-active');
                                btn.prop('disabled', false).text('<?php echo esc_js(__('Generate Map', 'ai-seo-client')); ?>');
                                status.addClass('tc-status-success').text('<?php echo esc_js(__('Cluster map ready', 'ai-seo-client')); ?>');
                                if (typeof sseoHideLoader === 'function') sseoHideLoader();
                            } else if (state.status === 'failed') {
                                clearInterval(pollInterval);
                                spinner.removeClass('is-active');
                                btn.prop('disabled', false).text('<?php echo esc_js(__('Generate Map', 'ai-seo-client')); ?>');
                                status.addClass('tc-status-error').html('<?php echo esc_js(__('Failed', 'ai-seo-client')); ?>: ' + (state.error || '') + ' <button type="button" class="button button-small tc-process-now" data-queue="' + res.queue_id + '" style="margin-left:10px;"><?php echo esc_js(__('Retry now', 'ai-seo-client')); ?></button>');
                                if (typeof sseoHideLoader === 'function') sseoHideLoader();
                            } else if (state.status === 'cancelled') {
                                clearInterval(pollInterval);
                                spinner.removeClass('is-active');
                                btn.prop('disabled', false).text('<?php echo esc_js(__('Generate Map', 'ai-seo-client')); ?>');
                                status.text('<?php echo esc_js(__('Cancelled', 'ai-seo-client')); ?>');
                                if (typeof sseoHideLoader === 'function') sseoHideLoader();
                            } else {
                                pendingPolls++;
                                var statusText = '<?php echo esc_js(__('Status', 'ai-seo-client')); ?>: ' + state.status + ' (#' + res.queue_id + ')';
                                // After 6 consecutive pending polls (~30s), show a "Process now"
                                // button so the user can manually trigger processing if WP-Cron
                                // is not running reliably.
                                if (pendingPolls >= 6 && state.status === 'pending') {
                                    statusText += ' <button type="button" class="button button-small tc-process-now" data-queue="' + res.queue_id + '" style="margin-left:10px;"><?php echo esc_js(__('Process now', 'ai-seo-client')); ?></button>';
                                }
                                status.html(statusText);
                            }
                        }).catch(function(err) {
                            clearInterval(pollInterval);
                            spinner.removeClass('is-active');
                            btn.prop('disabled', false).text('<?php echo esc_js(__('Generate Map', 'ai-seo-client')); ?>');
                            status.addClass('tc-status-error').text(err.message || '<?php echo esc_js(__('Status check failed', 'ai-seo-client')); ?>');
                            if (typeof sseoHideLoader === 'function') sseoHideLoader();
                        });
                    }, 5000);
                }).catch(function(err) {
                    spinner.removeClass('is-active');
                    btn.prop('disabled', false).text('<?php echo esc_js(__('Generate Map', 'ai-seo-client')); ?>');
                    status.addClass('tc-status-error').text(err.message || '<?php echo esc_js(__('Failed to queue cluster map', 'ai-seo-client')); ?>');
                    if (typeof sseoHideLoader === 'function') sseoHideLoader();
                });
            });

            // Process now — manually trigger cluster map queue processing
            // (useful when WP-Cron is unreliable or disabled)
            $(document).on('click', '.tc-process-now', function() {
                var queueId = $(this).data('queue');
                var processBtn = $(this);
                var status = $('#tc-generate-status');
                var spinner = $('#tc-generate-spinner');
                processBtn.prop('disabled', true).text('<?php echo esc_js(__('Processing...', 'ai-seo-client')); ?>');
                spinner.addClass('is-active');
                status.text('<?php echo esc_js(__('Processing cluster map...', 'ai-seo-client')); ?>').removeClass('tc-status-error tc-status-success');
                if (typeof sseoShowLoader === 'function') sseoShowLoader();

                wp.apiFetch({
                    path: '/sseo-ai/v1/clusters/map-queue/' + queueId + '/process',
                    method: 'POST'
                }).then(function(state) {
                    spinner.removeClass('is-active');
                    if (typeof sseoHideLoader === 'function') sseoHideLoader();
                    if (state.status === 'completed' && state.result) {
                        currentCluster = state.result;
                        renderCluster(state.result);
                        $('#tc-result').show();
                        $('#tc-generate').prop('disabled', false).text('<?php echo esc_js(__('Generate Map', 'ai-seo-client')); ?>');
                        status.addClass('tc-status-success').text('<?php echo esc_js(__('Cluster map ready', 'ai-seo-client')); ?>');
                    } else if (state.status === 'failed') {
                        $('#tc-generate').prop('disabled', false).text('<?php echo esc_js(__('Generate Map', 'ai-seo-client')); ?>');
                        status.addClass('tc-status-error').html('<?php echo esc_js(__('Failed', 'ai-seo-client')); ?>: ' + (state.error || '') + ' <button type="button" class="button button-small tc-process-now" data-queue="' + queueId + '" style="margin-left:10px;"><?php echo esc_js(__('Retry now', 'ai-seo-client')); ?></button>');
                    } else {
                        $('#tc-generate').prop('disabled', false).text('<?php echo esc_js(__('Generate Map', 'ai-seo-client')); ?>');
                        status.text('<?php echo esc_js(__('Status', 'ai-seo-client')); ?>: ' + state.status);
                    }
                }).catch(function(err) {
                    spinner.removeClass('is-active');
                    if (typeof sseoHideLoader === 'function') sseoHideLoader();
                    $('#tc-generate').prop('disabled', false).text('<?php echo esc_js(__('Generate Map', 'ai-seo-client')); ?>');
                    status.addClass('tc-status-error').text(err.message || '<?php echo esc_js(__('Processing failed', 'ai-seo-client')); ?>');
                });
            });

            // Audit
            $('#tc-audit').on('click', function() {
                var topic = $('#tc-topic').val().trim();
                if (!topic) return;
                var btn = $(this);
                btn.prop('disabled', true).text('<?php echo esc_js(__('Auditing...', 'ai-seo-client')); ?>');
                if (typeof sseoShowLoader === 'function') sseoShowLoader();

                wp.apiFetch({
                    path: '/sseo-ai/v1/clusters/audit',
                    method: 'POST',
                    data: { topic: topic }
                }).then(function(data) {
                    var s = data.stats;
                    var html = '<div class="postbox" style="padding:20px;">' +
                        '<h3 style="margin-top:0;">Existing Content for "' + data.topic + '"</h3>' +
                        '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:15px;margin-bottom:15px;">' +
                        '<div style="text-align:center;padding:10px;background:#f0f7ff;border-radius:6px;"><div style="font-size:24px;font-weight:bold;">' + s.total_pages + '</div><div style="font-size:11px;color:#666;">Pages Found</div></div>' +
                        '<div style="text-align:center;padding:10px;background:#ecfdf5;border-radius:6px;"><div style="font-size:24px;font-weight:bold;">' + s.total_words.toLocaleString() + '</div><div style="font-size:11px;color:#666;">Total Words</div></div>' +
                        '<div style="text-align:center;padding:10px;background:#fef3c7;border-radius:6px;"><div style="font-size:24px;font-weight:bold;">' + s.avg_seo_score + '</div><div style="font-size:11px;color:#666;">Avg SEO Score</div></div>' +
                        '<div style="text-align:center;padding:10px;background:' + (s.has_pillar ? '#ecfdf5' : '#fcf0f1') + ';border-radius:6px;"><div style="font-size:24px;font-weight:bold;">' + (s.has_pillar ? '✓' : '✕') + '</div><div style="font-size:11px;color:#666;">Has Pillar Page</div></div>' +
                        '</div>';

                    if (data.existing_content.length) {
                        html += '<table class="wp-list-table widefat striped" style="font-size:12px;"><thead><tr><th>Title</th><th>Words</th><th>Score</th><th>Keyphrase</th></tr></thead><tbody>';
                        data.existing_content.forEach(function(p) {
                            html += '<tr><td><a href="' + (p.edit_url||'#') + '">' + p.title + '</a></td>' +
                                '<td>' + p.word_count + '</td>' +
                                '<td>' + (p.seo_score !== null ? p.seo_score : '—') + '</td>' +
                                '<td>' + (p.focus_keyphrase || '—') + '</td></tr>';
                        });
                        html += '</tbody></table>';
                    } else {
                        html += '<p style="color:#999;">No existing content found for this topic.</p>';
                    }
                    html += '</div>';
                    $('#tc-audit-result').html(html).show();
                    btn.prop('disabled', false).text('<?php echo esc_js(__('Audit Existing Content', 'ai-seo-client')); ?>');
                }).catch(function(err) {
                    showInlineError(err.message || '<?php echo esc_js(__('Audit failed', 'ai-seo-client')); ?>');
                    btn.prop('disabled', false).text('<?php echo esc_js(__('Audit Existing Content', 'ai-seo-client')); ?>');
                }).finally(function() {
                    if (typeof sseoHideLoader === 'function') sseoHideLoader();
                });
            });

            // Generate content for cluster item
            function generateClusterContent(title, keyword, wordCount, contentType, buttonElement, scheduleDate) {
                var context = currentCluster ? 'Part of "' + (currentCluster.topic || '') + '" topic cluster. Related pages: ' +
                    ((currentCluster.clusters||[]).map(function(c) {
                        return (c.hub_page?.title||'') + ', ' + (c.supporting_pages||[]).map(function(s){return s.title;}).join(', ');
                    }).join(', ').substring(0, 500)) : '';

                var btn = $(buttonElement);
                var originalText = btn.text();
                btn.prop('disabled', true).text('<?php echo esc_js(__('Generating...', 'ai-seo-client')); ?>');
                if (typeof sseoShowLoader === 'function') sseoShowLoader();

                var payload = {
                    title: title,
                    keyword: keyword,
                    word_count: wordCount || 1500,
                    content_type: contentType || 'article',
                    cluster_context: context,
                    cluster_id: currentCluster ? (currentCluster.id || 0) : 0,
                    cluster_role: contentType || ''
                };
                if (scheduleDate) {
                    payload.schedule_date = scheduleDate;
                }

                wp.apiFetch({
                    path: '/sseo-ai/v1/clusters/generate-content',
                    method: 'POST',
                    data: payload
                }).then(function(res) {
                    var statusLabel = scheduleDate ? '✓ <?php echo esc_js(__('Scheduled', 'ai-seo-client')); ?>' : '✓ <?php echo esc_js(__('Created Draft', 'ai-seo-client')); ?>';
                    btn.prop('disabled', false).html(statusLabel);
                    btn.after(' <a href="' + res.edit_url + '" class="button button-small" style="margin-left:5px;"><?php echo esc_js(__('Edit', 'ai-seo-client')); ?></a>');
                    if (res.quality_scores) {
                        var scoreText = Object.entries(res.quality_scores).map(function(e) { return e[0] + ': ' + e[1]; }).join(', ');
                        btn.after('<span style="margin-left:8px;font-size:11px;color:#64748b;">' + escapeHtml(scoreText) + '</span>');
                    }
                    setTimeout(function() {
                        btn.text(originalText).prop('disabled', false);
                    }, 3000);
                }).catch(function(err) {
                    showInlineError('<?php echo esc_js(__('Error:', 'ai-seo-client')); ?> ' + (err.message || '<?php echo esc_js(__('Failed to generate content', 'ai-seo-client')); ?>'));
                    btn.prop('disabled', false).text(originalText);
                }).finally(function() {
                    if (typeof sseoHideLoader === 'function') sseoHideLoader();
                });
            }

            function renderCluster(data) {
                currentCluster = data;
                $('#tc-total-pages').text(data.total_pages || 0);
                $('#tc-clusters').text((data.clusters||[]).length);
                $('#tc-months').text(data.estimated_months || 0);
                $('#tc-authority').text(data.topical_authority_score_potential || 0);

                // Pillar with generate + delete button
                var p = data.pillar_page || {};
                $('#tc-pillar').html(
                    '<div style="display:flex;justify-content:space-between;align-items:flex-start;">' +
                    '<div>' +
                    '<h2 style="margin-top:0;color:#379fd3;">🏛️ ' + (p.title || 'Pillar Page') + '</h2>' +
                    '<p>' + (p.description || '') + '</p>' +
                    '<div style="display:flex;gap:15px;font-size:13px;color:#666;">' +
                    '<span>🎯 ' + (p.target_keyword || '') + '</span>' +
                    '<span>📝 ' + (p.target_word_count || 3000) + ' words</span>' +
                    '<span>🔍 ' + (p.search_intent || '') + '</span></div>' +
                    '</div>' +
                    '<div style="display:flex;gap:5px;align-items:center;">' +
                    '<button type="button" class="button button-primary tc-generate-content" ' +
                    'data-title="' + escapeHtml(p.title || '') + '" ' +
                    'data-keyword="' + escapeHtml(p.target_keyword || '') + '" ' +
                    'data-words="' + (p.target_word_count || 3000) + '" ' +
                    'data-type="pillar"><?php echo esc_js(__('Generate Content', 'ai-seo-client')); ?></button>' +
                    '<button type="button" class="button button-small tc-delete-card" data-role="pillar" title="<?php echo esc_js(__('Delete this topic', 'ai-seo-client')); ?>" style="color:#dc2626;border-color:#fecaca;">&times;</button>' +
                    '</div>' +
                    '</div>'
                );

                // Clusters with generate + delete buttons
                var gridHtml = '';
                var priorityColors = {high:'#16a34a',medium:'#d97706',low:'#6b7280'};
                var priorityTooltips = {
                    high: '<?php echo esc_js(__('High priority: high search volume or strong strategic value', 'ai-seo-client')); ?>',
                    medium: '<?php echo esc_js(__('Medium priority: moderate priority for your content plan', 'ai-seo-client')); ?>',
                    low: '<?php echo esc_js(__('Low priority: lower search volume / nice to have', 'ai-seo-client')); ?>'
                };
                (data.clusters || []).forEach(function(cl, idx) {
                    gridHtml += '<div class="postbox" style="padding:15px;margin-bottom:15px;">' +
                        '<div style="display:flex;justify-content:space-between;align-items:center;">' +
                        '<h3 style="margin-top:0;">📂 ' + cl.name + '</h3>' +
                        '<button type="button" class="button button-small tc-delete-card" data-role="cluster" data-cluster-idx="' + idx + '" title="<?php echo esc_js(__('Delete this cluster', 'ai-seo-client')); ?>" style="color:#dc2626;border-color:#fecaca;">&times;</button>' +
                        '</div>' +
                        '<p style="font-size:12px;color:#666;">' + (cl.description || '') + '</p>';

                    // Hub with generate + delete button
                    var h = cl.hub_page || {};
                    gridHtml += '<div style="padding:10px;background:#eff6ff;border-radius:6px;border-left:3px solid #379fd3;margin:10px 0;display:flex;justify-content:space-between;align-items:center;">' +
                        '<div>' +
                        '<strong>Hub: ' + (h.title || '') + '</strong>' +
                        '<div style="font-size:11px;color:#666;margin-top:4px;">' +
                        '🎯 ' + (h.target_keyword || '') + ' · ' + (h.target_word_count || 0) + ' words · ' +
                        '<span style="color:' + (priorityColors[h.priority]||'#999') + ';" title="' + (priorityTooltips[h.priority] || '') + '">' + (h.priority || '') + '</span></div>' +
                        '</div>' +
                        '<div style="display:flex;gap:5px;align-items:center;">' +
                        '<button type="button" class="button tc-generate-content" ' +
                        'data-title="' + escapeHtml(h.title || '') + '" ' +
                        'data-keyword="' + escapeHtml(h.target_keyword || '') + '" ' +
                        'data-words="' + (h.target_word_count || 1500) + '" ' +
                        'data-type="hub"><?php echo esc_js(__('Generate', 'ai-seo-client')); ?></button>' +
                        '<button type="button" class="button button-small tc-delete-card" data-role="hub" data-cluster-idx="' + idx + '" title="<?php echo esc_js(__('Delete this topic', 'ai-seo-client')); ?>" style="color:#dc2626;border-color:#fecaca;">&times;</button>' +
                        '</div>' +
                        '</div>';

                    // Supporting pages with generate + delete buttons
                    (cl.supporting_pages || []).forEach(function(sp, spIdx) {
                        gridHtml += '<div style="padding:8px 10px;margin:4px 0 4px 20px;background:#f9f9f9;border-left:2px solid #93c5fd;border-radius:0 4px 4px 0;font-size:13px;display:flex;justify-content:space-between;align-items:center;">' +
                            '<div>' + sp.title +
                            '<div style="font-size:11px;color:#666;">' +
                            '🎯 ' + (sp.target_keyword || '') + ' · ' + (sp.target_word_count || 0) + 'w · ' +
                            '<span style="background:#e0e7ff;padding:1px 4px;border-radius:2px;font-size:10px;">' + (sp.content_type || '') + '</span>' +
                            '</div></div>' +
                            '<div style="display:flex;gap:3px;align-items:center;">' +
                            '<button type="button" class="button button-small tc-generate-content" ' +
                            'data-title="' + escapeHtml(sp.title || '') + '" ' +
                            'data-keyword="' + escapeHtml(sp.target_keyword || '') + '" ' +
                            'data-words="' + (sp.target_word_count || 800) + '" ' +
                            'data-type="supporting"><?php echo esc_js(__('Generate', 'ai-seo-client')); ?></button>' +
                            '<button type="button" class="button button-small tc-delete-card" data-role="supporting" data-cluster-idx="' + idx + '" data-page-idx="' + spIdx + '" title="<?php echo esc_js(__('Delete this topic', 'ai-seo-client')); ?>" style="color:#dc2626;border-color:#fecaca;padding:1px 5px;">&times;</button>' +
                            '</div>';
                    });
                    gridHtml += '</div>';
                });
                $('#tc-cluster-grid').html(gridHtml);

                // Bind generate buttons
                $(document).off('click', '.tc-generate-content').on('click', '.tc-generate-content', function() {
                    var btn = $(this);
                    generateClusterContent(
                        btn.data('title'),
                        btn.data('keyword'),
                        btn.data('words'),
                        btn.data('type'),
                        this
                    );
                });

                // Bind delete-card buttons (pillar/hub/supporting/cluster)
                $(document).off('click', '.tc-delete-card').on('click', '.tc-delete-card', function() {
                    var role = $(this).data('role');
                    var clusterIdx = $(this).data('cluster-idx');
                    var pageIdx = $(this).data('page-idx');
                    if (!confirm('<?php echo esc_js(__('Delete this topic from the cluster?', 'ai-seo-client')); ?>')) return;

                    if (role === 'pillar') {
                        delete currentCluster.pillar_page;
                    } else if (role === 'cluster') {
                        if (currentCluster.clusters) currentCluster.clusters.splice(clusterIdx, 1);
                    } else if (role === 'hub') {
                        if (currentCluster.clusters && currentCluster.clusters[clusterIdx]) {
                            delete currentCluster.clusters[clusterIdx].hub_page;
                        }
                    } else if (role === 'supporting') {
                        if (currentCluster.clusters && currentCluster.clusters[clusterIdx] && currentCluster.clusters[clusterIdx].supporting_pages) {
                            currentCluster.clusters[clusterIdx].supporting_pages.splice(pageIdx, 1);
                        }
                    }
                    // Re-render the cluster grid and review table
                    renderCluster(currentCluster);
                });

                // Linking
                var linkHtml = '';
                (data.internal_linking_strategy || []).forEach(function(rule) {
                    linkHtml += '<li style="padding:6px 10px;margin:3px 0;background:#ecfdf5;border-left:3px solid #059669;border-radius:0 4px 4px 0;font-size:13px;">🔗 ' + rule + '</li>';
                });
                $('#tc-linking').html(linkHtml);

                // Calendar
                var calHtml = '';
                (data.content_calendar || []).forEach(function(w) {
                    calHtml += '<div style="padding:12px;background:#f9f9f9;border-radius:6px;border-top:3px solid #379fd3;">' +
                        '<strong>Week ' + w.week + '</strong><br>' +
                        '<span style="font-size:12px;color:#666;">' + w.action + '</span><br>' +
                        '<span style="font-size:11px;color:#379fd3;">' + (w.pages || []).join(', ') + '</span></div>';
                });
                $('#tc-calendar').html(calHtml);
                
                // Populate review table
                populateReviewTable(data);

                // Set default schedule start date to tomorrow if empty
                if (!$('#tc-schedule-start').val()) {
                    var tomorrow = new Date();
                    tomorrow.setDate(tomorrow.getDate() + 1);
                    var yyyy = tomorrow.getFullYear();
                    var mm = String(tomorrow.getMonth() + 1).padStart(2, '0');
                    var dd = String(tomorrow.getDate()).padStart(2, '0');
                    $('#tc-schedule-start').val(yyyy + '-' + mm + '-' + dd);
                }

                // Suggest gap based on content calendar (fallback to 3 days)
                var totalPages = data.total_pages || (window.tcAllPages || []).length;
                var months = data.estimated_months || 1;
                if (totalPages && months) {
                    var suggestedGap = Math.max(1, Math.round((months * 30) / totalPages));
                    $('#tc-schedule-gap').val(suggestedGap);
                }
            }

            // Review Table Population
            function populateReviewTable(data) {
                var allPages = [];
                var idCounter = 0;
                
                // Add pillar page
                if (data.pillar_page) {
                    allPages.push({
                        id: 'pillar-' + idCounter++,
                        title: data.pillar_page.title,
                        type: 'Pillar Page',
                        typeClass: 'pillarp',
                        keyword: data.pillar_page.target_keyword,
                        words: data.pillar_page.target_word_count || 3000,
                        priority: 'high',
                        content_type: 'pillar'
                    });
                }
                
                // Add cluster pages
                (data.clusters || []).forEach(function(cluster) {
                    // Hub page
                    if (cluster.hub_page) {
                        allPages.push({
                            id: 'hub-' + idCounter++,
                            title: cluster.hub_page.title,
                            type: 'Hub: ' + cluster.name,
                            typeClass: 'hub',
                            keyword: cluster.hub_page.target_keyword,
                            words: cluster.hub_page.target_word_count || 1500,
                            priority: cluster.hub_page.priority || 'medium',
                            content_type: 'hub'
                        });
                    }
                    
                    // Supporting pages
                    (cluster.supporting_pages || []).forEach(function(page) {
                        allPages.push({
                            id: 'support-' + idCounter++,
                            title: page.title,
                            type: 'Supporting',
                            typeClass: 'supporting',
                            keyword: page.target_keyword,
                            words: page.target_word_count || 800,
                            priority: page.priority || 'low',
                            content_type: 'supporting'
                        });
                    });
                });
                
                // Store for later use
                window.tcAllPages = allPages;
                
                // Render table
                renderReviewTable(allPages);
                updateReviewStats();
            }
            
            function renderReviewTable(pages) {
                var html = '';
                var priorityColors = {high:'#16a34a',medium:'#d97706',low:'#6b7280'};
                var priorityTooltips = {
                    high: '<?php echo esc_js(__('High priority: high search volume or strong strategic value', 'ai-seo-client')); ?>',
                    medium: '<?php echo esc_js(__('Medium priority: moderate priority for your content plan', 'ai-seo-client')); ?>',
                    low: '<?php echo esc_js(__('Low priority: lower search volume / nice to have', 'ai-seo-client')); ?>'
                };
                var priorityLabels = {high:'<?php echo esc_js(__('High', 'ai-seo-client')); ?>',medium:'<?php echo esc_js(__('Medium', 'ai-seo-client')); ?>',low:'<?php echo esc_js(__('Low', 'ai-seo-client')); ?>'};
                
                pages.forEach(function(page) {
                    var typeBadge = '';
                    if (page.typeClass === 'pillarp') typeBadge = '<span style="background:#e8f4fa;color:#8f39ac;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;">PILLAR</span>';
                    else if (page.typeClass === 'hub') typeBadge = '<span style="background:#fef3c7;color:#92400e;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;">HUB</span>';
                    else typeBadge = '<span style="background:#f3f4f6;color:#4b5563;padding:2px 8px;border-radius:4px;font-size:11px;">Supporting</span>';
                    
                    html += '<tr data-page-id="' + page.id + '" class="tc-page-row">' +
                        '<td style="text-align:center;"><input type="checkbox" class="tc-page-checkbox" data-page-id="' + page.id + '"></td>' +
                        '<td><strong>' + escapeHtml(page.title) + '</strong></td>' +
                        '<td>' + typeBadge + '</td>' +
                        '<td><code style="background:#f3f4f6;padding:2px 6px;border-radius:3px;font-size:11px;">' + escapeHtml(page.keyword || '-') + '</code></td>' +
                        '<td style="text-align:center;">' + page.words.toLocaleString() + '</td>' +
                        '<td style="text-align:center;"><span style="color:' + priorityColors[page.priority] + ';font-weight:600;font-size:12px;" title="' + (priorityTooltips[page.priority] || '') + '">' + priorityLabels[page.priority] + '</span></td>' +
                        '<td style="text-align:center;" class="tc-status-cell"><span class="tc-status-pending" style="background:#f3f4f6;color:#6b7280;padding:3px 10px;border-radius:12px;font-size:11px;"><?php echo esc_js(__('Pending', 'ai-seo-client')); ?></span></td>' +
                        '<td style="text-align:center;"><button type="button" class="button button-small tc-delete-page" data-page-id="' + page.id + '" title="<?php echo esc_js(__('Delete this topic', 'ai-seo-client')); ?>" style="color:#dc2626;border-color:#fecaca;line-height:1;padding:2px 6px;">&times;</button></td>' +
                        '</tr>';
                });
                
                $('#tc-pages-tbody').html(html);
                $('#tc-review-total').text(pages.length);
            }
            
            function updateReviewStats() {
                var selected = $('.tc-page-checkbox:checked').length;
                $('#tc-review-selected').text(selected);
                $('#tc-selected-count').text(selected);
                
                var totalWords = 0;
                $('.tc-page-checkbox:checked').each(function() {
                    var pageId = $(this).data('page-id');
                    var page = window.tcAllPages.find(function(p) { return p.id === pageId; });
                    if (page) totalWords += page.words;
                });
                $('#tc-review-words').text(totalWords.toLocaleString());
                
                // Estimate cost: ~$0.03 per 1000 words (OpenAI GPT-4)
                var estCost = (totalWords / 1000) * 0.03;
                $('#tc-review-est-cost').text('$' + estCost.toFixed(2));
            }

            // Toggle Review Section
            $('#tc-toggle-review').on('click', function() {
                $('#tc-review-section').slideToggle();
            });
            
            // Select All Checkbox
            $('#tc-select-all-checkbox').on('change', function() {
                $('.tc-page-checkbox').prop('checked', $(this).is(':checked'));
                updateReviewStats();
            });
            
            // Individual checkbox change
            $(document).on('change', '.tc-page-checkbox', function() {
                updateReviewStats();
            });
            
            // Select All Button
            $('#tc-select-all').on('click', function() {
                $('.tc-page-checkbox').prop('checked', true);
                $('#tc-select-all-checkbox').prop('checked', true);
                updateReviewStats();
            });
            
            // Deselect All Button
            $('#tc-deselect-all').on('click', function() {
                $('.tc-page-checkbox').prop('checked', false);
                $('#tc-select-all-checkbox').prop('checked', false);
                updateReviewStats();
            });

            // Delete individual topic/page from the review table
            $(document).on('click', '.tc-delete-page', function() {
                var pageId = $(this).data('page-id');
                if (!confirm('<?php echo esc_js(__('Delete this topic from the cluster?', 'ai-seo-client')); ?>')) return;
                // Remove from window.tcAllPages
                if (window.tcAllPages) {
                    window.tcAllPages = window.tcAllPages.filter(function(p) { return p.id !== pageId; });
                }
                // Remove the row
                $('tr[data-page-id="' + pageId + '"]').fadeOut(300, function() { $(this).remove(); });
                updateReviewStats();
            });

            // Generate All — selects all pages then triggers bulk generate
            $('#tc-generate-all').on('click', function() {
                if (!window.tcAllPages || window.tcAllPages.length === 0) {
                    showInlineError('<?php echo esc_js(__('No pages to generate. Generate a cluster map first.', 'ai-seo-client')); ?>');
                    return;
                }
                $('.tc-page-checkbox').prop('checked', true);
                $('#tc-select-all-checkbox').prop('checked', true);
                updateReviewStats();
                // Trigger the bulk generate flow
                $('#tc-bulk-generate').trigger('click');
            });

            // Inline error display helper (replaces alert() for better UX)
            function showInlineError(message) {
                $('#tc-error-text').text(message);
                $('#tc-error-msg').slideDown();
                $('html, body').animate({
                    scrollTop: $('#tc-error-msg').offset().top - 100
                }, 300);
            }
            window.showInlineError = showInlineError;

            // Bulk Generate — Queue-based background processing
            $('#tc-bulk-generate').on('click', function() {
                var selectedIds = [];
                $('.tc-page-checkbox:checked').each(function() {
                    selectedIds.push($(this).data('page-id'));
                });

                if (selectedIds.length === 0) {
                    alert('<?php echo esc_js(__('Please select at least one page to generate.', 'ai-seo-client')); ?>');
                    return;
                }

                // Scheduling settings
                var startDateInput = $('#tc-schedule-start').val();
                var gapDays = parseInt($('#tc-schedule-gap').val(), 10) || 3;
                if (!startDateInput) {
                    var tomorrow = new Date();
                    tomorrow.setDate(tomorrow.getDate() + 1);
                    var yyyy = tomorrow.getFullYear();
                    var mm = String(tomorrow.getMonth() + 1).padStart(2, '0');
                    var dd = String(tomorrow.getDate()).padStart(2, '0');
                    startDateInput = yyyy + '-' + mm + '-' + dd;
                }

                if (!confirm('<?php echo esc_js(__('Generate content for', 'ai-seo-client')); ?> ' + selectedIds.length + ' <?php echo esc_js(__('pages in the background? You can close this page — content will be generated and scheduled automatically.', 'ai-seo-client')); ?>')) {
                    return;
                }

                // Build pages array for queue
                var pages = [];
                selectedIds.forEach(function(pageId) {
                    var page = window.tcAllPages.find(function(p) { return p.id === pageId; });
                    if (page) {
                        pages.push({
                            title: page.title,
                            keyword: page.keyword,
                            word_count: page.words,
                            content_type: page.content_type
                        });
                    }
                });

                // Show progress
                $('#tc-bulk-progress').show();
                $('#tc-bulk-results').hide().html('');
                $('#tc-bulk-generate').prop('disabled', true);
                $('#tc-progress-bar').css('width', '0%').text('0%');
                $('#tc-progress-text').text('<?php echo esc_js(__('Submitting to background queue...', 'ai-seo-client')); ?>');
                $('#tc-progress-log').html('');

                function log(message) {
                    var time = new Date().toLocaleTimeString();
                    $('#tc-progress-log').prepend('[' + time + '] ' + message + '\n');
                }

                // Submit to queue endpoint
                wp.apiFetch({
                    path: '/sseo-ai/v1/clusters/queue',
                    method: 'POST',
                    data: {
                        pages: pages,
                        cluster_id: currentCluster ? (currentCluster.id || 0) : 0,
                        cluster_map_id: currentCluster ? (currentCluster.id || 0) : 0,
                        start_date: startDateInput + ' 09:00:00',
                        gap_days: gapDays
                    }
                }).then(function(res) {
                    log('✅ <?php echo esc_js(__('Queue created with', 'ai-seo-client')); ?> ' + res.total_items + ' <?php echo esc_js(__('items', 'ai-seo-client')); ?>');
                    $('#tc-progress-text').text('<?php echo esc_js(__('Queue active — generating in background...', 'ai-seo-client')); ?>');

                    // Mark all selected rows as queued
                    selectedIds.forEach(function(pageId) {
                        var $row = $('tr[data-page-id="' + pageId + '"]');
                        $row.find('.tc-status-cell').html('<span style="background:#fef3c7;color:#92400e;padding:3px 10px;border-radius:12px;font-size:11px;">⏳ <?php echo esc_js(__('Queued', 'ai-seo-client')); ?></span>');
                    });

                    // Poll for status
                    var queueId = res.queue_id;
                    var pollInterval = setInterval(function() {
                        wp.apiFetch({
                            path: '/sseo-ai/v1/clusters/queue/' + queueId
                        }).then(function(status) {
                            var percent = Math.round((status.completed + status.failed) / status.total * 100);
                            $('#tc-progress-bar').css('width', percent + '%').text(percent + '%');
                            $('#tc-progress-text').text(
                                status.completed + ' <?php echo esc_js(__('completed', 'ai-seo-client')); ?>, ' +
                                status.failed + ' <?php echo esc_js(__('failed', 'ai-seo-client')); ?>, ' +
                                status.pending + ' <?php echo esc_js(__('remaining', 'ai-seo-client')); ?>'
                            );

                            // Update row statuses
                            status.items.forEach(function(item, idx) {
                                var pageId = selectedIds[idx];
                                if (!pageId) return;
                                var $row = $('tr[data-page-id="' + pageId + '"]');

                                if (item.status === 'completed') {
                                    $row.find('.tc-status-cell').html('<a href="' + (item.edit_url || '#') + '" style="background:#dcfce7;color:#166534;padding:3px 10px;border-radius:12px;font-size:11px;text-decoration:none;">✓ <?php echo esc_js(__('Done', 'ai-seo-client')); ?></a>');
                                } else if (item.status === 'failed') {
                                    $row.find('.tc-status-cell').html('<span style="background:#fee2e2;color:#dc2626;padding:3px 10px;border-radius:12px;font-size:11px;">❌ <?php echo esc_js(__('Failed', 'ai-seo-client')); ?></span>');
                                } else if (item.status === 'processing') {
                                    $row.find('.tc-status-cell').html('<span style="background:#e8f4fa;color:#8f39ac;padding:3px 10px;border-radius:12px;font-size:11px;">⏳ <?php echo esc_js(__('Generating...', 'ai-seo-client')); ?></span>');
                                }
                            });

                            // Check if done
                            if (status.status === 'completed' || status.status === 'cancelled') {
                                clearInterval(pollInterval);
                                $('#tc-bulk-generate').prop('disabled', false);

                                var resultsHtml = '<div style="background:#f0fdf4;border:2px solid #16a34a;border-radius:8px;padding:20px;">' +
                                    '<h4 style="margin:0 0 15px 0;color:#166534;">✅ <?php echo esc_js(__('Content Generation Complete!', 'ai-seo-client')); ?></h4>' +
                                    '<p><?php echo esc_js(__('Generated', 'ai-seo-client')); ?> ' + status.completed + ' <?php echo esc_js(__('posts', 'ai-seo-client')); ?>' +
                                    (status.failed > 0 ? ', ' + status.failed + ' <?php echo esc_js(__('failed', 'ai-seo-client')); ?>' : '') + '.</p>' +
                                    '<a href="<?php echo esc_url(admin_url('edit.php?post_status=future&post_type=post')); ?>" class="button button-primary" style="background:#16a34a;border-color:#16a34a;margin-right:10px;"><?php echo esc_js(__('View Scheduled Posts', 'ai-seo-client')); ?></a>' +
                                    '<a href="<?php echo esc_url(admin_url('edit.php?post_status=draft&post_type=post')); ?>" class="button"><?php echo esc_js(__('View Drafts', 'ai-seo-client')); ?></a>' +
                                    '</div>';
                                $('#tc-bulk-results').html(resultsHtml).show();
                                log('✅ <?php echo esc_js(__('Queue completed', 'ai-seo-client')); ?>: ' + status.completed + ' <?php echo esc_js(__('done', 'ai-seo-client')); ?>, ' + status.failed + ' <?php echo esc_js(__('failed', 'ai-seo-client')); ?>');
                            }
                        }).catch(function(err) {
                            log('❌ <?php echo esc_js(__('Polling error', 'ai-seo-client')); ?>: ' + (err.message || 'unknown'));
                        });
                    }, 5000); // Poll every 5 seconds
                }).catch(function(err) {
                    alert('<?php echo esc_js(__('Error creating queue', 'ai-seo-client')); ?>: ' + (err.message || 'unknown'));
                    $('#tc-bulk-generate').prop('disabled', false);
                    $('#tc-bulk-progress').hide();
                });
            });

            // Escape HTML helper
            function escapeHtml(text) {
                if (!text) return '';
                return text.replace(/["']/g, function(m) {
                    return m === '"' ? '&quot;' : '&#039;';
                });
            }

            // Save
            $('#tc-save').on('click', function() {
                if (!currentCluster) return;
                wp.apiFetch({
                    path: '/sseo-ai/v1/clusters/save',
                    method: 'POST',
                    data: { cluster: currentCluster }
                }).then(function() {
                    alert('<?php echo esc_js(__('Cluster saved!', 'ai-seo-client')); ?>');
                    loadSaved();
                });
            });

            // Sync to Content Calendar
            $('#tc-sync-calendar').on('click', function() {
                if (!currentCluster) return;
                var btn = $(this);
                btn.prop('disabled', true).text('<?php echo esc_js(__('Syncing...', 'ai-seo-client')); ?>');
                var startDate = $('#tc-schedule-start').val() || '';
                var gapDays = parseInt($('#tc-schedule-gap').val(), 10) || 3;
                wp.apiFetch({
                    path: '/sseo-ai/v1/calendar/sync-cluster',
                    method: 'POST',
                    data: {
                        cluster: currentCluster,
                        start_date: startDate + ' 09:00:00',
                        gap_days: gapDays
                    }
                }).then(function(res) {
                    btn.prop('disabled', false).text('<?php echo esc_js(__('Sync to Content Calendar', 'ai-seo-client')); ?>');
                    var msg = '<?php echo esc_js(__("Synced", "ai-seo-client")); ?> ' + res.synced + '/' + res.total + ' <?php echo esc_js(__("pages to the content calendar as scheduled drafts.", "ai-seo-client")); ?>';
                    if (res.errors.length) {
                        msg += '\n<?php echo esc_js(__("Errors:", "ai-seo-client")); ?>\n' + res.errors.join('\n');
                    }
                    alert(msg);
                }).catch(function(err) {
                    btn.prop('disabled', false).text('<?php echo esc_js(__('Sync to Content Calendar', 'ai-seo-client')); ?>');
                    alert(err.message || 'Sync failed');
                });
            });
        });
        </script>
        <?php
    }
}
