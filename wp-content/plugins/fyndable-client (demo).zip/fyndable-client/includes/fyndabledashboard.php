<?php

namespace SSEOAIClient;

/**
 * Full-Page Dashboard Shell
 *
 * Replaces the WordPress admin chrome with a branded dashboard experience.
 * Existing admin pages are loaded inside an iframe within the shell.
 * An exit button (×) returns the user to the standard WordPress admin.
 */
class DashboardShell
{
    private Client $client;
    private array $menuItems = [];

    public function __construct(Client $client)
    {
        $this->client = $client;
    }

    public function register(): void
    {
        add_action('admin_head', [$this, 'hideWpChrome']);
        add_action('wp_ajax_sseo_ai_toggle_theme', [$this, 'toggleTheme']);
    }

    public function toggleTheme(): void
    {
        check_ajax_referer('sseo_ai_toggle_theme', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'ai-seo-client')], 403);
        }

        $dark = isset($_POST['dark']) && $_POST['dark'] === '1';
        update_option('sseo_ai_client_dark_theme', $dark ? '1' : '0');
        wp_send_json_success(['dark' => $dark]);
    }

    /**
     * Build the sidebar menu items based on license tier.
     */
    private function buildMenuItems(): void
    {
        $isLicenseValid = $this->client->licenseValidator->isLicenseValid();
        $tier = $this->client->licenseValidator->getLicenseTier();

        $this->menuItems = [
            [
                'slug' => 'ai-seo-client',
                'label' => __('Connection', 'ai-seo-client'),
                'icon' => '&#128279;',
                'always' => true,
            ],
        ];

        if ($isLicenseValid) {
            // Workflow order: research first, then plan, then create, then
            // measure, then optimise, then utilities.
            $this->menuItems[] = [
                'slug' => 'ai-seo-dashboard',
                'label' => __('Dashboard', 'ai-seo-client'),
                'icon' => '&#128202;',
            ];
            $this->menuItems[] = [
                'slug' => 'ai-seo-keywords',
                'label' => __('Keywords', 'ai-seo-client'),
                'icon' => '&#127919;',
            ];
            $this->menuItems[] = [
                'slug' => 'ai-seo-ideas',
                'label' => __('Ideas', 'ai-seo-client'),
                'icon' => '&#128161;',
            ];

            $professionalTiers = ['professional', 'business', 'agency', 'trial', 'dev'];
            $isPro = in_array($tier, $professionalTiers, true);

            if ($isPro) {
                $this->menuItems[] = [
                    'slug' => 'ai-seo-topic-clusters',
                    'label' => __('Topic Clusters', 'ai-seo-client'),
                    'icon' => '&#127919;',
                ];
            }

            if (in_array($tier, ['professional', 'business', 'agency', 'dev'], true)) {
                $this->menuItems[] = [
                    'slug' => 'ai-seo-automation',
                    'label' => __('ApexFlow', 'ai-seo-client'),
                    'icon' => '&#9889;',
                ];
            }

            $this->menuItems[] = [
                'slug' => 'ai-seo-content-calendar',
                'label' => __('Content Calendar', 'ai-seo-client'),
                'icon' => '&#128197;',
            ];
            $this->menuItems[] = [
                'slug' => 'ai-seo-created-posts',
                'label' => __('Created Posts', 'ai-seo-client'),
                'icon' => '&#9999;',
            ];
            $this->menuItems[] = [
                'slug' => 'ai-seo-competitor-research',
                'label' => __('Competitors', 'ai-seo-client'),
                'icon' => '&#128269;',
            ];

            if ($isPro) {
                $this->menuItems[] = [
                    'slug' => 'ai-seo-backlinks',
                    'label' => __('Backlinks', 'ai-seo-client'),
                    'icon' => '&#128279;',
                ];
                $this->menuItems[] = [
                    'slug' => 'ai-seo-advanced-backlinks',
                    'label' => __('Adv. Backlinks', 'ai-seo-client'),
                    'icon' => '&#129517;',
                ];
            }

            if ($isPro) {
                $this->menuItems[] = [
                    'slug' => 'ai-seo-rank-tracker',
                    'label' => __('Rank Tracker', 'ai-seo-client'),
                    'icon' => '&#128200;',
                ];
                $this->menuItems[] = [
                    'slug' => 'ai-seo-site-audit',
                    'label' => __('Site Audit', 'ai-seo-client'),
                    'icon' => '&#128269;',
                ];
            }

            $this->menuItems[] = [
                'slug' => 'ai-seo-link-manager',
                'label' => __('Link Manager', 'ai-seo-client'),
                'icon' => '&#128279;',
            ];
            $this->menuItems[] = [
                'slug' => 'ai-seo-bulk',
                'label' => __('Bulk Optimizer', 'ai-seo-client'),
                'icon' => '&#9989;',
            ];
            $this->menuItems[] = [
                'slug' => 'ai-seo-sitemaps',
                'label' => __('Sitemaps', 'ai-seo-client'),
                'icon' => '&#128506;',
            ];
            $this->menuItems[] = [
                'slug' => 'ai-seo-data-dashboard',
                'label' => __('SEO Data', 'ai-seo-client'),
                'icon' => '&#128200;',
            ];

            if ($isPro) {
                $this->menuItems[] = [
                    'slug' => 'ai-seo-google-data',
                    'label' => __('Google Data', 'ai-seo-client'),
                    'icon' => '&#128202;',
                ];
            }

            $this->menuItems[] = [
                'slug' => 'ai-seo-llm-tracker',
                'label' => __('LLM Tracker', 'ai-seo-client'),
                'icon' => '&#129504;',
            ];

            if ($isPro) {
                $this->menuItems[] = [
                    'slug' => 'ai-seo-ab-testing',
                    'label' => __('A/B Testing', 'ai-seo-client'),
                    'icon' => '&#129514;',
                ];
            }

            // Utility items at the bottom of the sidebar
            $this->menuItems[] = [
                'slug' => 'ai-seo-ai-tools',
                'label' => __('AI Tools', 'ai-seo-client'),
                'icon' => '&#129302;',
            ];
            $this->menuItems[] = [
                'slug' => 'ai-seo-integrations',
                'label' => __('Integrations', 'ai-seo-client'),
                'icon' => '&#128268;',
            ];
            $this->menuItems[] = [
                'slug' => 'ai-seo-support',
                'label' => __('Support', 'ai-seo-client'),
                'icon' => '&#128172;',
            ];
            $this->menuItems[] = [
                'slug' => 'ai-seo-feedback',
                'label' => __('Feedback', 'ai-seo-client'),
                'icon' => '&#128172;',
            ];
        }

        $this->menuItems[] = [
            'slug' => 'ai-seo-settings',
            'label' => __('Settings', 'ai-seo-client'),
            'icon' => '&#9881;',
            'always' => true,
        ];
    }

    /**
     * Hide WordPress admin chrome when on dashboard pages.
     * - On the shell page: hide ALL WP chrome (menu, bar, footer, notices)
     * - In the iframe (fyndable_shell=1): hide WP chrome for clean content
     */
    public function hideWpChrome(): void
    {
        $screen = get_current_screen();
        if (!$screen) {
            return;
        }

        $isShellPage = $screen->id === 'toplevel_page_fyndable-dashboard';
        $isIframePage = isset($_GET['fyndable_shell']);
        $isDashboardPage = strpos($screen->id, 'ai-seo') !== false
            || strpos($screen->id, 'fyndable') !== false
            || $isShellPage;

        if (!$isDashboardPage) {
            return;
        }

        if ($isShellPage) {
            // Shell page: hide everything from WordPress, take over full viewport
            echo '<style>
                #wpadminbar, #adminmenumain, #adminmenuwrap, #adminmenu,
                #wpfooter, #screen-meta, #screen-meta-links,
                #contextual-help-link-wrap, #screen-options-link-wrap,
                .notice, .notice-success, .notice-error, .notice-warning,
                .update-nag, .updated, .error,
                #wpcontent > .wrap > h1, #wpbody-content > .wrap > h1 {
                    display: none !important;
                }
                #wpcontent, #wpbody, #wpbody-content {
                    margin-left: 0 !important;
                    padding: 0 !important;
                }
                html.wp-toolbar {
                    padding-top: 0 !important;
                    overflow: hidden !important;
                }
                body {
                    overflow: hidden !important;
                }
                #wpcontent > .wrap,
                #wpbody-content > .wrap {
                    margin: 0 !important;
                    padding: 0 !important;
                    max-width: none !important;
                }
            </style>';
        }

        // For all dashboard pages (including iframe content): use JS to detect iframe
        // and hide WP chrome even when fyndable_shell param is missing from URL
        if (!$isShellPage) {
            echo '<script>
            (function() {
                if (window.self !== window.top) {
                    // We are inside an iframe — hide all WP chrome
                    var style = document.createElement("style");
                    style.textContent = "\
                        #wpadminbar, #adminmenumain, #adminmenuwrap, #adminmenu,\
                        #adminmenuback, #wpfooter, #screen-meta, #screen-meta-links,\
                        #contextual-help-link-wrap, #screen-options-link-wrap,\
                        .notice, .notice-success, .notice-error, .notice-warning, .notice-info,\
                        .update-nag, .updated, .error, .is-dismissible,\
                        #wp-version-message, .update-plugins, .update-count {\
                            display: none !important;\
                        }\
                        #wpcontent, #wpbody, #wpbody-content {\
                            margin-left: 0 !important;\
                            padding: 0 !important;\
                        }\
                        html.wp-toolbar {\
                            padding-top: 0 !important;\
                        }\
                        .wrap, .wrap.sseo-ai-modern {\
                            margin: 0 !important;\
                            padding: 0 !important;\
                        }\
                        .sseo-ai-dashboard-card {\
                            margin: 20px 0px !important;\
                        }\
                        html, body {\
                            overflow-x: hidden !important;\
                        }\
                        *, *::before, *::after {\
                            box-sizing: border-box;\
                        }\
                    ";
                    document.head.appendChild(style);

                    // Intercept links to dashboard admin pages: append fyndable_shell=1
                    // and the current theme flag so they stay inside the iframe shell
                    // and keep the selected light/dark mode.
                    document.addEventListener("click", function(e) {
                        var link = e.target.closest("a");
                        if (!link || !link.href) return;
                        var url = link.href;
                        // Only intercept links to admin.php with page=ai-seo- or page=fyndable-
                        if (url.indexOf("admin.php") === -1) return;
                        if (url.indexOf("page=ai-seo-") === -1 && url.indexOf("page=fyndable-") === -1) return;
                        // Skip links with target=_blank
                        if (link.target === "_blank") return;
                        e.preventDefault();
                        var sep = url.indexOf("?") !== -1 ? "&" : "?";
                        if (url.indexOf("fyndable_shell") === -1) {
                            url += sep + "fyndable_shell=1";
                            sep = "&";
                        }
                        if (url.indexOf("fyndable_dark") === -1) {
                            var darkParam = document.body.classList.contains("fyndable-dark") ? "1" : "0";
                            url += sep + "fyndable_dark=" + darkParam;
                        }
                        window.location.href = url;
                    });

                    // Also intercept form submissions that redirect to dashboard admin pages
                    // (e.g. options.php redirects back to admin.php?page=ai-seo-*)
                    // Handle this by modifying the _wp_http_referer to include fyndable_shell
                    document.addEventListener("DOMContentLoaded", function() {
                        document.querySelectorAll("form").forEach(function(form) {
                            var formAction = form.getAttribute("action") || "";
                            if (formAction.indexOf("options.php") !== -1) {
                                // Update the _wp_http_referer to include fyndable_shell and theme
                                var referrer = form.querySelector("input[name=_wp_http_referer]");
                                if (referrer && referrer.value.indexOf("fyndable_shell") === -1) {
                                    var sep = referrer.value.indexOf("?") !== -1 ? "&" : "?";
                                    var darkParam = document.body.classList.contains("fyndable-dark") ? "1" : "0";
                                    referrer.value = referrer.value + sep + "fyndable_shell=1&fyndable_dark=" + darkParam;
                                }
                            }
                        });
                    });
                }
            })();
            </script>';

            // Also apply CSS immediately if fyndable_shell is set (no waiting for JS)
            if ($isIframePage) {
                echo '<style>
                    #wpadminbar, #adminmenumain, #adminmenuwrap, #adminmenu,
                    #adminmenuback, #wpfooter, #screen-meta, #screen-meta-links,
                    #contextual-help-link-wrap, #screen-options-link-wrap,
                    .notice, .notice-success, .notice-error, .notice-warning, .notice-info,
                    .update-nag, .updated, .error, .is-dismissible,
                    #wp-version-message, .update-plugins, .update-count,
                    .auto-fold #adminmenu, .auto-fold #adminmenumain,
                    .auto-fold #adminmenuwrap, .auto-fold #adminmenuback {
                        display: none !important;
                    }
                    #wpcontent, #wpbody, #wpbody-content {
                        margin-left: 0 !important;
                        padding: 0 !important;
                    }
                    html.wp-toolbar {
                        padding-top: 0 !important;
                    }
                    .wrap, .wrap.sseo-ai-modern {
                        margin: 0 !important;
                        padding: 0 !important;
                    }
                    .sseo-ai-dashboard-card {
                        margin: 20px 0px !important;
                    }
                    html, body {
                        overflow-x: hidden !important;
                    }
                    *, *::before, *::after {
                        box-sizing: border-box;
                    }
                </style>';
            }
        }
    }

    /**
     * Render the dashboard shell (within WordPress .wrap).
     * WP chrome is hidden via hideWpChrome() CSS on admin_head.
     */
    public function render(): void
    {
        $this->buildMenuItems();

        // Determine which page to load in the iframe
        $currentPage = isset($_GET['fyndable_page']) ? sanitize_key($_GET['fyndable_page']) : 'ai-seo-dashboard';

        // Never load the shell page inside the shell; that would create a
        // shell-in-shell loop. Fall back to the dashboard content page.
        if (empty($currentPage) || $currentPage === 'fyndable-dashboard') {
            $currentPage = 'ai-seo-dashboard';
        }

        $licenseValid = $this->client->licenseValidator->isLicenseValid();

        // If not licensed, force connection page
        if (!$licenseValid) {
            $currentPage = 'ai-seo-client';
        }

        $darkTheme = get_option('sseo_ai_client_dark_theme', '0') === '1';

        // Build iframe URL
        $iframeUrl = admin_url('admin.php');
        $iframeUrl = add_query_arg('page', $currentPage, $iframeUrl);
        $iframeUrl = add_query_arg('fyndable_shell', '1', $iframeUrl);
        $iframeUrl = add_query_arg('fyndable_dark', $darkTheme ? '1' : '0', $iframeUrl);

        // Pass through relevant query parameters (e.g. keyword, error messages)
        // to the iframe so the loaded page can display them.
        $passThroughParams = ['keyword', 'error', 'activated', 'deactivated', 'validated'];
        foreach ($passThroughParams as $param) {
            if (isset($_GET[$param]) && $_GET[$param] !== '') {
                $iframeUrl = add_query_arg($param, sanitize_text_field($_GET[$param]), $iframeUrl);
            }
        }

        $exitUrl = admin_url('admin.php?page=' . $currentPage);

        // Load white-label branding set by the SaaS dashboard
        $whiteLabel = get_option('sseo_ai_white_label', []);
        $companyName = !empty($whiteLabel['company_name']) ? $whiteLabel['company_name'] : 'Fyndable';
        $companyLogo = !empty($whiteLabel['company_logo']) ? $whiteLabel['company_logo'] : '';
        $brandName = $companyName . ' Smart SEO';
        // Only apply custom colors when a company name is set; otherwise fall back to Fyndable defaults
        $hasCustomBrand = !empty($whiteLabel['company_name']);
        $primaryColor = $hasCustomBrand ? (sanitize_hex_color($whiteLabel['primary_color'] ?? '') ?: '#379fd3') : '#379fd3';
        $secondaryColor = $hasCustomBrand ? (sanitize_hex_color($whiteLabel['secondary_color'] ?? '') ?: '#8f39ac') : '#8f39ac';
        $usePrimaryOnly = $hasCustomBrand && !empty($whiteLabel['use_primary_only']);
        $supportEmail = !empty($whiteLabel['support_email']) ? $whiteLabel['support_email'] : '';
        $supportUrl = !empty($whiteLabel['support_url']) ? $whiteLabel['support_url'] : '';

        if ($usePrimaryOnly) {
            $topBarGradient = $primaryColor;
            $activeGradient = $primaryColor;
        } else {
            $topBarGradient = "linear-gradient(135deg, {$primaryColor} 0%, {$secondaryColor} 100%)";
            $activeGradient = "linear-gradient(135deg, {$primaryColor} 0%, {$secondaryColor} 100%)";
        }
        ?>
        <style>
            .fyndable-shell-wrap {
                position: fixed;
                top: 0; left: 0; right: 0; bottom: 0;
                z-index: 999999;
                background: #f0f2f5;
                font-family: Outfit, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif;
            }

            /* Top bar with gradient */
            .fyndable-topbar {
                height: 56px;
                background: <?php echo esc_attr($topBarGradient); ?>;
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 0 20px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.15);
                position: relative;
                z-index: 100;
                flex-shrink: 0;
            }
            .fyndable-topbar-brand {
                display: flex;
                align-items: center;
                gap: 10px;
                color: #fff;
            }
            .fyndable-topbar-logo {
                font-size: 20px;
                font-weight: 700;
                letter-spacing: -0.3px;
            }
            .fyndable-topbar-logo img {
                max-height: 36px;
                max-width: 180px;
                display: block;
            }
            .fyndable-topbar-logo span { font-weight: 400; opacity: 0.9; }
            .fyndable-topbar-badge {
                font-size: 10px;
                font-weight: 600;
                
                letter-spacing: 0.5px;
                padding: 3px 10px;
                border-radius: 20px;
                background: rgba(255,255,255,0.2);
                color: #fff;
            }
            .fyndable-topbar-actions {
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .fyndable-exit-btn {
                display: flex;
                align-items: center;
                gap: 6px;
                background: rgba(255,255,255,0.15);
                color: #fff;
                border: 1px solid rgba(255,255,255,0.3);
                border-radius: 8px;
                padding: 6px 14px;
                font-size: 13px;
                font-weight: 500;
                text-decoration: none;
                cursor: pointer;
                transition: background 0.15s;
            }
            .fyndable-exit-btn:hover {
                background: rgba(255,255,255,0.25);
                color: #fff;
            }
            .fyndable-theme-toggle {
                display: inline-flex;
                align-items: center;
                gap: 7px;
                min-height: 32px;
                padding: 5px 10px;
                border: 1px solid rgba(255,255,255,.3);
                border-radius: 8px;
                background: rgba(255,255,255,.15);
                color: #fff;
                cursor: pointer;
            }
            .fyndable-theme-toggle:hover { background: rgba(255,255,255,.25); }
            .fyndable-theme-toggle-icon { font-size: 17px; line-height: 1; }
            .fyndable-theme-toggle-track {
                position: relative;
                width: 30px;
                height: 16px;
                border-radius: 999px;
                background: rgba(255,255,255,.35);
            }
            .fyndable-theme-toggle-track::after {
                content: '';
                position: absolute;
                top: 2px;
                left: 2px;
                width: 12px;
                height: 12px;
                border-radius: 50%;
                background: #fff;
                transition: transform .2s ease;
            }
            .fyndable-theme-toggle[aria-pressed="true"] .fyndable-theme-toggle-track::after { transform: translateX(14px); }
            .fyndable-exit-x {
                font-size: 18px;
                line-height: 1;
                font-weight: 300;
            }

            /* Main layout */
            .fyndable-shell-body {
                display: flex;
                height: calc(100vh - 56px);
            }

            /* Sidebar */
            .fyndable-sidebar {
                width: 240px;
                background: #fff;
                border-right: 1px solid #e5e7eb;
                display: flex;
                flex-direction: column;
                overflow-y: auto;
                flex-shrink: 0;
            }
            .fyndable-sidebar-nav {
                list-style: none;
                padding: 12px 0;
                flex: 1;
                margin: 0;
            }
            .fyndable-sidebar-nav li {
                margin: 2px 8px;
            }
            .fyndable-sidebar-nav a {
                display: flex;
                align-items: center;
                gap: 10px;
                padding: 10px 14px;
                text-decoration: none;
                color: #374151;
                font-size: 13px;
                font-weight: 500;
                border-radius: 8px;
                transition: all 0.15s;
                cursor: pointer;
            }
            .fyndable-sidebar-nav a:hover {
                background: #f3f4f6;
                color: <?php echo esc_attr($primaryColor); ?>;
            }
            .fyndable-sidebar-nav a.active {
                background: <?php echo esc_attr($activeGradient); ?>;
                color: #fff;
                font-weight: 600;
                box-shadow: 0 2px 6px <?php echo esc_attr($primaryColor); ?>4d;
            }
            .fyndable-sidebar-nav .fyndable-nav-icon {
                font-size: 16px;
                width: 20px;
                text-align: center;
                flex-shrink: 0;
            }
            .fyndable-sidebar-footer {
                padding: 16px;
                border-top: 1px solid #e5e7eb;
                font-size: 11px;
                color: #9ca3af;
                text-align: center;
            }
            .fyndable-sidebar-footer a {
                color: #6b7280;
                text-decoration: none;
            }
            .fyndable-footer-brand {
                margin-bottom: 6px;
                font-size: 12px;
                color: #6b7280;
            }
            .fyndable-footer-brand img {
                max-height: 24px;
                max-width: 160px;
                display: block;
                margin: 0 auto 4px;
            }
            .fyndable-footer-brand strong { color: #6b7280; }
            .fyndable-footer-brand span { font-weight: 600; opacity: 0.8; }
            .fyndable-footer-support { margin-top: 4px; }

            /* Content area */
            .fyndable-content {
                flex: 1;
                overflow: hidden;
                position: relative;
            }
            .fyndable-content iframe {
                width: 100%;
                height: 100%;
                border: none;
                display: block;
            }

            /* Loading overlay */
            .fyndable-loading {
                position: absolute;
                top: 0; left: 0; right: 0; bottom: 0;
                background: #f0f2f5;
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 50;
                transition: opacity 0.3s;
            }
            .fyndable-loading.hidden {
                opacity: 0;
                pointer-events: none;
            }
            .fyndable-spinner {
                width: 36px;
                height: 36px;
                border: 3px solid #e5e7eb;
                border-top-color: <?php echo esc_attr($primaryColor); ?>;
                border-radius: 50%;
                animation: fyndable-spin 0.8s linear infinite;
            }
            @keyframes fyndable-spin {
                to { transform: rotate(360deg); }
            }

            /* Mobile responsive */
            @media (max-width: 768px) {
                .fyndable-sidebar {
                    width: 60px;
                }
                .fyndable-sidebar-nav a {
                    justify-content: center;
                    padding: 12px;
                }
                .fyndable-sidebar-nav a span:not(.fyndable-nav-icon) {
                    display: none;
                }
                .fyndable-sidebar-footer { display: none; }
                .fyndable-topbar-badge { display: none; }
            }
        </style>
        <div class="fyndable-shell-wrap">
            <div class="fyndable-topbar">
                <div class="fyndable-topbar-brand">
                    <div class="fyndable-topbar-logo">
                        <?php if ($companyLogo): ?>
                            <img src="<?php echo esc_url($companyLogo); ?>" alt="<?php echo esc_attr($companyName); ?>" title="<?php echo esc_attr($companyName); ?>">
                        <?php else: ?>
                            <?php echo esc_html($brandName); ?>
                        <?php endif; ?>
                    </div>
                    <div class="fyndable-topbar-badge"><?php esc_html_e('Dashboard', 'ai-seo-client'); ?></div>
                </div>
                <div class="fyndable-topbar-actions">
                    <button type="button" id="fyndable-theme-toggle" class="fyndable-theme-toggle" aria-pressed="<?php echo $darkTheme ? 'true' : 'false'; ?>" title="<?php esc_attr_e('Switch light/dark theme', 'ai-seo-client'); ?>">
                        <span class="fyndable-theme-toggle-icon" aria-hidden="true">☀</span>
                        <span class="fyndable-theme-toggle-track" aria-hidden="true"></span>
                        <span class="fyndable-theme-toggle-icon" aria-hidden="true">☾</span>
                    </button>
                    <a href="<?php echo esc_url($exitUrl); ?>" class="fyndable-exit-btn" title="<?php esc_attr_e('Exit to WordPress', 'ai-seo-client'); ?>">
                        <span class="fyndable-exit-x">&times;</span>
                        <span><?php esc_html_e('Exit', 'ai-seo-client'); ?></span>
                    </a>
                </div>
            </div>

            <div class="fyndable-shell-body">
                <nav class="fyndable-sidebar">
                    <ul class="fyndable-sidebar-nav">
                        <?php foreach ($this->menuItems as $item): ?>
                            <?php $isActive = $item['slug'] === $currentPage; ?>
                            <li>
                                <a href="#" data-slug="<?php echo esc_attr($item['slug']); ?>" class="<?php echo $isActive ? 'active' : ''; ?>">
                                    <span class="fyndable-nav-icon"><?php echo $item['icon']; ?></span>
                                    <span><?php echo esc_html($item['label']); ?></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <div class="fyndable-sidebar-footer">
                        <div class="fyndable-footer-brand">
                            <?php if ($companyLogo): ?>
                                <img src="<?php echo esc_url($companyLogo); ?>" alt="<?php echo esc_attr($companyName); ?>" title="<?php echo esc_attr($companyName); ?>">
                            <?php else: ?>
                                <?php echo esc_html($brandName); ?>
                            <?php endif; ?>
                        </div>
                        <?php if ($supportUrl || $supportEmail): ?>
                            <div class="fyndable-footer-support">
                                <?php if ($supportUrl): ?>
                                    <a href="<?php echo esc_url($supportUrl); ?>" target="_blank"><?php esc_html_e('Support', 'ai-seo-client'); ?></a>
                                <?php elseif ($supportEmail): ?>
                                    <a href="mailto:<?php echo esc_attr($supportEmail); ?>"><?php esc_html_e('Support', 'ai-seo-client'); ?></a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </nav>

                <div class="fyndable-content">
                    <div class="fyndable-loading" id="fyndable-loading">
                        <div class="fyndable-spinner"></div>
                    </div>
                    <iframe id="fyndable-frame" src="<?php echo esc_url($iframeUrl); ?>"></iframe>
                </div>
            </div>
        </div>
        <script>
        (function() {
            var iframe = document.getElementById('fyndable-frame');
            var loading = document.getElementById('fyndable-loading');
            var navLinks = document.querySelectorAll('.fyndable-sidebar-nav a');
            var themeToggle = document.getElementById('fyndable-theme-toggle');
            var storageKey = 'fyndableDarkTheme';

            // Determine current theme: prefer localStorage so the shell and iframe stay
            // in sync even if the async DB update has not completed yet.
            var storedDark = localStorage.getItem(storageKey);
            var isDark = storedDark !== null
                ? storedDark === '1'
                : themeToggle.getAttribute('aria-pressed') === 'true';

            function applyTheme(dark) {
                themeToggle.setAttribute('aria-pressed', dark ? 'true' : 'false');
                document.body.classList.toggle('fyndable-dark', dark);
                try {
                    if (iframe.contentDocument && iframe.contentDocument.body) {
                        iframe.contentDocument.body.classList.toggle('fyndable-dark', dark);
                    }
                } catch (e) {}
            }

            function setTheme(dark) {
                isDark = dark;
                localStorage.setItem(storageKey, dark ? '1' : '0');
                applyTheme(dark);
            }

            applyTheme(isDark);

            // Hide loading when iframe loads and ensure the loaded page follows the theme.
            iframe.addEventListener('load', function() {
                loading.classList.add('hidden');
                applyTheme(isDark);
            });

            themeToggle.addEventListener('click', function() {
                var dark = !isDark;
                setTheme(dark);

                var data = new FormData();
                data.append('action', 'sseo_ai_toggle_theme');
                data.append('nonce', '<?php echo esc_js(wp_create_nonce('sseo_ai_toggle_theme')); ?>');
                data.append('dark', dark ? '1' : '0');
                fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                    method: 'POST',
                    credentials: 'same-origin',
                    body: data
                });
            });

            function buildIframeUrl(slug) {
                return '<?php echo esc_js(admin_url('admin.php')); ?>' +
                    '?page=' + encodeURIComponent(slug) +
                    '&fyndable_shell=1' +
                    '&fyndable_dark=' + (isDark ? '1' : '0');
            }

            // Navigation switching
            navLinks.forEach(function(link) {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    var slug = link.getAttribute('data-slug');
                    if (!slug) return;

                    // Update active state
                    navLinks.forEach(function(l) { l.classList.remove('active'); });
                    link.classList.add('active');

                    // Show loading and update iframe
                    loading.classList.remove('hidden');
                    iframe.src = buildIframeUrl(slug);

                    // Update URL hash for state persistence
                    window.location.hash = slug;
                });
            });

            // Restore state from hash on load
            var hash = window.location.hash.replace('#', '');
            // Never restore the shell page itself inside the iframe.
            if (hash === 'fyndable-dashboard' || !hash) {
                hash = 'ai-seo-dashboard';
            }
            if (hash) {
                navLinks.forEach(function(link) {
                    if (link.getAttribute('data-slug') === hash) {
                        navLinks.forEach(function(l) { l.classList.remove('active'); });
                        link.classList.add('active');
                        loading.classList.remove('hidden');
                        iframe.src = buildIframeUrl(hash);
                    }
                });
            }
        })();
        </script>
        <?php
    }
}
