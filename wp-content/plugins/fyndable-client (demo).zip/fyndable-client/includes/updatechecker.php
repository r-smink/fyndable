<?php

namespace SSEOAIClient;

/**
 * Update Checker
 *
 * Hooks into WordPress's plugin update system to check for updates
 * from the SaaS Dashboard's UpdateServer endpoint.
 *
 * Uses `pre_set_site_transient_update_plugins` for update checks
 * and `plugins_api` for the "View details" popup.
 */
class UpdateChecker
{
    private Settings $settings;
    private const CACHE_KEY = 'sseo_ai_update_check';
    private const CACHE_TTL = 6 * HOUR_IN_SECONDS;

    public function __construct(Settings $settings)
    {
        $this->settings = $settings;
    }

    public function register(): void
    {
        add_filter('pre_set_site_transient_update_plugins', [$this, 'checkForUpdates']);
        add_filter('plugins_api', [$this, 'filterPluginInfo'], 10, 3);
        add_filter('plugin_row_meta', [$this, 'addUpdateMeta'], 10, 2);
        add_action('admin_action_sseo_ai_force_update_check', [$this, 'handleForceCheck']);
        add_action('admin_notices', [$this, 'renderForceCheckNotice']);
        // Clear the update cache after the plugin is updated so the stale
        // "has_update" result doesn't persist for the remaining cache TTL.
        add_action('upgrader_process_complete', [$this, 'clearCacheAfterUpgrade'], 10, 2);
    }

    /**
     * Clear the update check cache after a plugin upgrade completes.
     */
    public function clearCacheAfterUpgrade($upgrader, $hookExtra): void
    {
        if (!is_array($hookExtra) || ($hookExtra['action'] ?? '') !== 'update') {
            return;
        }
        if (($hookExtra['type'] ?? '') !== 'plugin') {
            return;
        }

        // Clear for any plugin update (our own or others) — cheap and safe.
        // For a targeted clear, check $hookExtra['plugins'] against our basename.
        $pluginFile = plugin_basename(SSEO_AI_CLIENT_PLUGIN_FILE);
        $plugins = $hookExtra['plugins'] ?? [];
        if (!empty($plugins) && is_array($plugins) && !in_array($pluginFile, $plugins, true)) {
            return;
        }

        delete_transient(self::CACHE_KEY);
    }

    /**
     * Check for plugin updates via SaaS dashboard.
     */
    public function checkForUpdates($transient)
    {
        if (!is_object($transient)) {
            return $transient;
        }

        // Only check if license is active
        $licenseStatus = get_option('sseo_ai_client_license_status', 'inactive');
        if ($licenseStatus === 'inactive') {
            return $transient;
        }

        // Use cached result to avoid API call on every page load
        $cached = get_transient(self::CACHE_KEY);
        if ($cached !== false && is_array($cached)) {
            // Re-verify against the currently installed version. The cache may
            // be stale if the plugin was just updated to the same (or a newer)
            // version than what the cache says is "latest".
            $cachedLatest = $cached['latest_version'] ?? '';
            if (!empty($cachedLatest) && version_compare($cachedLatest, SSEO_AI_CLIENT_VERSION, '<=')) {
                // Installed version is up to date or newer than the cached
                // "latest" — clear the stale cache and don't show an update.
                delete_transient(self::CACHE_KEY);
                return $transient;
            }

            if (!empty($cached['has_update']) && !empty($cached['download_url'])) {
                $transient = $this->addUpdateToTransient($transient, $cached);
            }
            return $transient;
        }

        // Make API call to check for updates
        $result = $this->fetchUpdateInfo();
        if (is_wp_error($result)) {
            // Cache negative result for shorter time on error
            set_transient(self::CACHE_KEY, ['has_update' => false], HOUR_IN_SECONDS);
            return $transient;
        }

        set_transient(self::CACHE_KEY, $result, self::CACHE_TTL);

        if (!empty($result['has_update']) && !empty($result['download_url'])) {
            $transient = $this->addUpdateToTransient($transient, $result);
        }

        return $transient;
    }

    /**
     * Add update data to the transient.
     */
    private function addUpdateToTransient($transient, array $result): object
    {
        $pluginFile = plugin_basename(SSEO_AI_CLIENT_PLUGIN_FILE);

        $newVersion = $result['latest_version'] ?? SSEO_AI_CLIENT_VERSION;

        // Safety net: never show an "update" to the same or older version.
        if (version_compare($newVersion, SSEO_AI_CLIENT_VERSION, '<=')) {
            return $transient;
        }

        $obj = new \stdClass();
        $obj->slug = 'fyndable-client';
        $obj->plugin = $pluginFile;
        $obj->new_version = $newVersion;
        $obj->url = get_option('sseo_ai_client_dashboard_url', '');
        $obj->package = $result['download_url'] ?? '';
        $obj->tested = get_bloginfo('version');
        $obj->requires = $result['min_wp_version'] ?? '6.0';

        $transient->response[$pluginFile] = $obj;

        return $transient;
    }

    /**
     * Fetch update info from SaaS dashboard.
     */
    private function fetchUpdateInfo(): array|\WP_Error
    {
        $licenseKey = get_option(SSEO_AI_CLIENT_LICENSE_OPTION, '');
        $tenantKey = get_option(SSEO_AI_CLIENT_TENANT_OPTION, '');
        $dashboardUrl = get_option('sseo_ai_client_dashboard_url', '');

        if (empty($licenseKey) || empty($tenantKey) || empty($dashboardUrl)) {
            return new \WP_Error('not_configured', 'Dashboard not configured');
        }

        // Normalize URL and disable auto-redirect to prevent POST->GET conversion
        $dashboardUrl = str_replace('http://', 'https://', rtrim($dashboardUrl, '/'));
        $response = wp_remote_post(
            rtrim($dashboardUrl, '/') . '/wp-json/ai-seo-saas/v1/updates/check',
            [
                'body' => [
                    'license_key' => $licenseKey,
                    'tenant_key' => $tenantKey,
                    'current_version' => SSEO_AI_CLIENT_VERSION,
                ],
                'timeout' => 15,
                'sslverify' => $this->settings->sslVerify(),
                'redirection' => 0,
            ]
        );

        if (is_wp_error($response)) {
            return $response;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (empty($body['success'])) {
            return new \WP_Error('check_failed', $body['message'] ?? 'Update check failed');
        }

        return $body;
    }

    /**
     * Filter the plugin info popup (View details).
     */
    public function filterPluginInfo($result, $action, $args)
    {
        if ($action !== 'plugin_information') {
            return $result;
        }

        if (!isset($args->slug) || $args->slug !== 'fyndable-client') {
            return $result;
        }

        $cached = get_transient(self::CACHE_KEY);
        if (!$cached || !is_array($cached)) {
            $cached = $this->fetchUpdateInfo();
            if (is_wp_error($cached)) {
                return $result;
            }
        }

        $pluginInfo = new \stdClass();
        $pluginInfo->name = 'Fyndable';
        $pluginInfo->slug = 'fyndable-client';
        $pluginInfo->version = $cached['latest_version'] ?? SSEO_AI_CLIENT_VERSION;
        $pluginInfo->author = '<a href="https://fyndable.com">Fyndable</a>';
        $pluginInfo->homepage = 'https://fyndable.com';
        $pluginInfo->requires = $cached['min_wp_version'] ?? '6.0';
        $pluginInfo->tested = get_bloginfo('version');
        $pluginInfo->last_updated = $cached['last_checked'] ?? current_time('mysql');
        $pluginInfo->downloaded = 0;
        $pluginInfo->active_installs = 0;
        $pluginInfo->sections = [
            'description' => '<p>Advanced AI-powered SEO plugin by Fyndable with comprehensive optimization features.</p>',
            'changelog' => $this->formatChangelog($cached['changelog'] ?? ''),
        ];

        return $pluginInfo;
    }

    /**
     * Format changelog as HTML.
     */
    private function formatChangelog(string $changelog): string
    {
        if (empty($changelog)) {
            return '<p>No changelog available.</p>';
        }

        $html = '<div style="font-family: monospace; white-space: pre-wrap;">' . esc_html($changelog) . '</div>';

        return $html;
    }

    /**
     * Add "Check for updates" link in the plugin row.
     */
    public function addUpdateMeta(array $links, string $file): array
    {
        if ($file !== plugin_basename(SSEO_AI_CLIENT_PLUGIN_FILE)) {
            return $links;
        }

        $forceUrl = wp_nonce_url(
            admin_url('admin.php?action=sseo_ai_force_update_check'),
            'sseo_ai_force_update_check'
        );

        $links[] = '<a href="' . esc_url($forceUrl) . '">' .
            __('Check for Updates', 'ai-seo-client') . '</a>';

        return $links;
    }

    /**
     * Handle the forced update check request.
     * Clears the cache, refreshes the update transient, then redirects back
     * to the plugins page with a result notice.
     */
    public function handleForceCheck(): void
    {
        if (!current_user_can('update_plugins')) {
            wp_die(esc_html__('You do not have permission to check for updates.', 'ai-seo-client'));
        }

        check_admin_referer('sseo_ai_force_update_check');

        $this->forceCheck();

        // Re-fetch update info immediately so the result is fresh
        $result = $this->fetchUpdateInfo();
        $notice = 'no_update';

        if (is_wp_error($result)) {
            $notice = 'error';
        } elseif (!empty($result['has_update'])) {
            $notice = 'has_update';
            set_transient(self::CACHE_KEY, $result, self::CACHE_TTL);
        } else {
            set_transient(self::CACHE_KEY, $result, self::CACHE_TTL);
        }

        wp_safe_redirect(
            admin_url('plugins.php?sseo_ai_update_check=' . $notice)
        );
        exit;
    }

    /**
     * Show a notice on the plugins page after a forced update check.
     */
    public function renderForceCheckNotice(): void
    {
        $result = $_GET['sseo_ai_update_check'] ?? '';
        if (empty($result)) {
            return;
        }

        if ($result === 'has_update') {
            echo '<div class="notice notice-success is-dismissible"><p>' .
                esc_html__('A new version of Fyndable is available. See the update notice above.', 'ai-seo-client') .
                '</p></div>';
        } elseif ($result === 'no_update') {
            echo '<div class="notice notice-success is-dismissible"><p>' .
                esc_html__('Fyndable is up to date.', 'ai-seo-client') .
                '</p></div>';
        } elseif ($result === 'error') {
            echo '<div class="notice notice-error is-dismissible"><p>' .
                esc_html__('Could not check for updates. Please verify your license and dashboard connection.', 'ai-seo-client') .
                '</p></div>';
        }
    }

    /**
     * Force a manual update check (clears cache).
     */
    public function forceCheck(): void
    {
        delete_transient(self::CACHE_KEY);
        delete_site_transient('update_plugins');
    }
}
