# Changelog

## v2.4.0 (2026-10-09)

### Added
- **Cannibalization Dashboard** — new tab on the Rank Tracker page. Detects posts/pages competing for the same focus keyphrase (`same_focus_keyphrase`), tracked keywords matching multiple posts (`tracked_keyword_multi_match`, marks the intended target post), and tracked keywords with no targeting post. REST: `GET /sseo-ai/v1/cannibalization/report` (6h cache) + `POST /sseo-ai/v1/cannibalization/scan`.

### Security
- Google `refresh_token` now stored encrypted at rest (`enc1:` AES-256-GCM, key derived from WP salts); legacy plaintext values decrypt transparently and are re-encrypted on next store.

### Removed
- Dead `AuditService` module (`auditservice.php`) — instantiated but never called; cannibalization and technical audit coverage now lives in RankTracker and the Technical SEO Auditor.

## v2.3.2 (2026-09-22)

### Fixed / Improved
- **Google OAuth token refresh** — Access tokens for Google Search Console / GA4 / Ads now refresh via the SaaS dashboard (`/google/refresh` endpoint) instead of calling Google directly. The direct call always failed because the OAuth `client_secret` only exists server-side, forcing a daily re-connect. Requires SaaS Dashboard v1.6.2+.
- **Token storage** — `restStoreTokens()` and `exchangeCode()` now set a `created` timestamp and preserve an existing `refresh_token` when Google doesn't return a new one.

## v2.0.0 (2026-09-01)

### Major Release
- Bump major version to 2.0.0.

## v1.8.0 (2026-08-19)

### New Features
- **Post Auto-Cleaner** — Automatically trashes AI-generated posts that receive no traffic within a configurable period. Uses an internal view counter (bots and logged-in users excluded). Settings: enable/disable, days threshold (default 60), max views (default 0). Daily cron + REST endpoints for preview and manual run. Available to all tiers.

### Fixed / Improved
- **Agency white-label download** — White-label package builder now downloads the latest client plugin from updates.fyndable.ai when the plugin is not locally installed, ensuring agency customers always get the latest version. Falls back to packaged zips if the update server is unavailable.

## v1.7.1 (2026-08-19)

### Fixed / Improved
- **Upgrade button** — "Upgrade Now →" button on locked-feature pages now links to the Customer Portal on the SaaS dashboard (with dashboard-URL fallback) instead of the local Connection page. Opens in a new tab.
- **Portal URL storage** — Client stores `portal_url` from `tenant/status` and `license/activate` responses in `sseo_ai_client_portal_url` option.
- **Ideas page upgrade link** — "Upgrade My Plan" link on the Ideas page now points to the Customer Portal instead of `#`.
- **Check for Updates link** — "Check for Updates" link in the plugin row now actually forces an update check (clears cache, re-fetches from SaaS dashboard) and shows a result notice, instead of just redirecting to the Settings page.
- **Plugin metadata cleanup** — Removed `FEATURES.md` and `REVIEW-EN-FEATURES.md` from the plugin package; only `README.md` and `CHANGELOG.md` are shipped.

## v1.5.1 (2026-07-15)

### New Features
- **Fynable Login Screen** — Fully branded WordPress `wp-login.php` with separate toggle (Settings → White-Label & Login). Works for all users/tiers.
- **Free Tier Toggle** — Onboarding free-tier skip can be toggled off; default is disabled for beta, code remains intact.

### Fixed / Improved
- **SaaS Dashboard Branding** — Topbar now shows `Fyndable Smart SEO` with a smaller `SaaS` suffix.
- **SaaS Login Header** — Login screen now shows `Fyndable Smart SEO` instead of `Fyndable SaaS`.

## v0.5-beta (2026-03-08)

### New Features
- **AI Content Rewriter** — Rewrite existing content in multiple modes: SEO optimize, improve readability, expand, condense, paraphrase, tone shift. Section-level and full-article rewriting. REST API endpoints.
- **Readability Score** — Flesch Reading Ease + Flesch-Kincaid Grade Level analysis. Dutch support via Flesch-Douma formula. Passive voice detection, transition word analysis, sentence/paragraph length checks. AI-powered improvement suggestions.
- **IndexNow Integration** — Instant search engine notification on publish/update/delete. Auto-generated API key with verification file. Submits to Bing and IndexNow API. Submission log tracking.
- **GSC Dashboard** — Google Search Console performance data directly in WordPress admin. Clicks, impressions, CTR, average position. Top queries and top pages tables. Period selection (7/28/90 days).
- **ImageClient** — Image processing utility for AI vision: base64 encoding, resize, EXIF metadata extraction.

### Fixed / Improved
- **ContentBrief** — Replaced `SerpService` dependency with `DashboardAPI` proxy. Added AI fallback for SERP data. Now fully functional without archived plugin.
- **KeywordExplorer** — Replaced `SerpService` + `TopicRepository` dependencies. Uses `DashboardAPI` for SERP data, stores clusters in `wp_options`. Added REST API endpoints and caching.
- **TechChecker** — Removed non-existent sub-checker class dependencies (`SchemaValidator`, `HreflangChecker`, `RobotsChecker`, `RedirectChecker`). All checks now self-contained: JSON-LD validation, hreflang analysis, robots.txt parsing, redirect chain detection, meta robots/title/canonical/description checks.

### Module Registration
- Registered 12 previously unregistered modules in `client.php`:
  - **Core tier**: LSIKeywords, RolePermissions, ExtendedSitemaps, PageSpeedClient, ReadabilityScore, IndexNow
  - **Starter+**: ImageAltGenerator, ContentRewriter
  - **Professional+**: ContentBrief, KeywordExplorer, GscDashboard
  - **Business+**: AIRepurposer

### UI
- Complete admin CSS overhaul (`client-admin.css`): CSS custom properties design system, modern cards/buttons/inputs/tables, stat cards, badges, score circles, SERP preview, analysis lists, loading spinner, responsive breakpoints.

### Documentation
- Created comprehensive `README.md` with full feature overview (50+ modules), license tiers, REST API endpoints, admin pages, competitive matrix vs RankMath/Yoast/AIOSEO/WPSEO AI/MarketMuse/NeuronWriter/SurferSEO.

---

## v0.4-alpha (previous)
- Initial MarketMuse/NeuronWriter competitive features: ContentOptimizer, SerpCompetitor, TopicCluster, KeywordDifficulty
- Core SEO features: TruSEO, SmartTags, Sitemaps, Breadcrumbs, OpenGraph, Canonical, Schema, Local SEO, Rank Tracker, etc.
