<?php

namespace SSEOAIClient;

/**
 * Unified Post Meta Box with Tabs
 * 
 * Replaces 20+ individual meta boxes on the post edit screen
 * with a single "Fyndable SEO" meta box containing tabbed sections.
 */
class PostMetaBox
{
    private array $tabs = [];

    /**
     * Register a tab with its label and render callback.
     * 
     * @param string   $id       Tab identifier
     * @param string   $label    Tab label shown in navigation
     * @param callable $callback Render callback receiving WP_Post
     * @param string   $context  Context: 'normal' (all post types) or 'attachment'
     */
    public function addTab(string $id, string $label, callable $callback, string $context = 'normal'): void
    {
        $this->tabs[] = [
            'id' => $id,
            'label' => $label,
            'callback' => $callback,
            'context' => $context,
        ];
    }

    public function register(): void
    {
        add_action('add_meta_boxes', [$this, 'addMetaBox']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAssets']);
    }

    public function addMetaBox(): void
    {
        $postTypes = get_post_types(['public' => true]);

        // Separate normal tabs from attachment-only tabs
        $normalTabs = array_filter($this->tabs, fn($t) => $t['context'] === 'normal');
        $attachmentTabs = array_filter($this->tabs, fn($t) => $t['context'] === 'attachment');

        if (!empty($normalTabs)) {
            foreach ($postTypes as $postType) {
                add_meta_box(
                    'fyndable_seo_meta',
                    __('Fyndable SEO', 'ai-seo-client'),
                    [$this, 'renderMetaBox'],
                    $postType,
                    'normal',
                    'high'
                );
            }
        }

        if (!empty($attachmentTabs)) {
            add_meta_box(
                'fyndable_seo_meta_attachment',
                __('Fyndable SEO', 'ai-seo-client'),
                [$this, 'renderAttachmentMetaBox'],
                'attachment',
                'normal',
                'high'
            );
        }
    }

    public function enqueueAssets(string $hook): void
    {
        if (!in_array($hook, ['post.php', 'post-new.php', 'attachment.php'], true)) {
            return;
        }

        wp_register_style('fyndable-post-metabox', false);
        wp_enqueue_style('fyndable-post-metabox');
        wp_add_inline_style('fyndable-post-metabox', $this->getInlineCSS());

        wp_register_script('fyndable-post-metabox', false);
        wp_enqueue_script('fyndable-post-metabox');
        wp_add_inline_script('fyndable-post-metabox', $this->getInlineJS());
    }

    public function renderMetaBox(\WP_Post $post): void
    {
        $tabs = array_filter($this->tabs, fn($t) => $t['context'] === 'normal');
        $this->renderTabbedContent($post, $tabs);
    }

    public function renderAttachmentMetaBox(\WP_Post $post): void
    {
        $tabs = array_filter($this->tabs, fn($t) => $t['context'] === 'attachment');
        $this->renderTabbedContent($post, $tabs);
    }

    private function renderTabbedContent(\WP_Post $post, array $tabs): void
    {
        if (empty($tabs)) {
            echo '<p>' . esc_html__('No SEO options available.', 'ai-seo-client') . '</p>';
            return;
        }

        echo '<div class="fyndable-seo-tabs">';

        // Tab navigation
        echo '<ul class="fyndable-seo-tab-nav">';
        foreach ($tabs as $index => $tab) {
            $active = $index === 0 ? ' class="active"' : '';
            printf(
                '<li%s><a href="#" data-tab="%s">%s</a></li>',
                $active,
                esc_attr($tab['id']),
                esc_html($tab['label'])
            );
        }
        echo '</ul>';

        // Tab panels
        foreach ($tabs as $index => $tab) {
            $display = $index === 0 ? '' : ' style="display:none;"';
            printf('<div class="fyndable-seo-tab-panel" id="%s"%s>', esc_attr($tab['id']), $display);
            call_user_func($tab['callback'], $post);
            echo '</div>';
        }

        echo '</div>';
    }

    private function getInlineCSS(): string
    {
        return <<<'CSS'
.fyndable-seo-tabs { margin: -6px -12px -12px; }
.fyndable-seo-tab-nav {
    display: flex; flex-wrap: wrap; margin: 0; padding: 0;
    border-bottom: 2px solid #2563eb; background: #f6f7f7;
}
.fyndable-seo-tab-nav li { list-style: none; margin: 0; }
.fyndable-seo-tab-nav li a {
    display: block; padding: 10px 16px; text-decoration: none;
    color: #50575e; font-size: 13px; font-weight: 500;
    border-bottom: 3px solid transparent; margin-bottom: -2px;
    transition: all 0.15s;
}
.fyndable-seo-tab-nav li a:hover { color: #2563eb; background: #fff; }
.fyndable-seo-tab-nav li.active a {
    color: #2563eb; border-bottom-color: #2563eb; background: #fff;
    font-weight: 600;
}
.fyndable-seo-tab-panel { padding: 16px 12px; }
.fyndable-seo-tab-panel h3,
.fyndable-seo-tab-panel h4 { margin-top: 0; }
.fyndable-seo-tab-panel table.form-table { margin-top: 10px; }
.fyndable-seo-tab-panel .inside { margin: 0; padding: 0; }
CSS;
    }

    private function getInlineJS(): string
    {
        return <<<'JS'
(function() {
    document.addEventListener('DOMContentLoaded', function() {
        var navItems = document.querySelectorAll('.fyndable-seo-tab-nav li');
        navItems.forEach(function(li) {
            var link = li.querySelector('a');
            if (!link) return;
            link.addEventListener('click', function(e) {
                e.preventDefault();
                var tabId = link.getAttribute('data-tab');
                var container = link.closest('.fyndable-seo-tabs');
                if (!container) return;
                container.querySelectorAll('.fyndable-seo-tab-nav li').forEach(function(el) {
                    el.classList.remove('active');
                });
                li.classList.add('active');
                container.querySelectorAll('.fyndable-seo-tab-panel').forEach(function(panel) {
                    panel.style.display = panel.id === tabId ? '' : 'none';
                });
            });
        });
    });
})();
JS;
    }
}
